<?php 
/*
  Plugin Name: Shortcode Addons
  Version: 1.5.2
 */

return '1.5.2';