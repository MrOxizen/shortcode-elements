<?php 
/*
  Plugin Name: Shortcode Addons
  Version: 1.5.1
 */

return '1.5.1';