<?php 
/*
  Plugin Name: Shortcode Addons
  Version: 1.5.3
 */

return '1.5.3';