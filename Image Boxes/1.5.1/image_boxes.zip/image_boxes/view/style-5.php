<?php

if (!defined('ABSPATH'))
    exit;

function oxi_image_boxes_style_5_shortcode($styledata = FALSE, $listdata = FALSE, $user = 'user') {
    $stylename = $styledata['style_name'];
    $oxiid = $styledata['id'];
    $stylefiles = explode('||#||', $styledata['css']);
    $styledata = explode('|', $stylefiles[0]);

    echo '<div class="oxi-addons-container">
            <div class="oxi-addons-row">';
    foreach ($listdata as $value) {
        $data = explode('||#||', $value['files']);
        echo'<div class="oxi_addons_container_' . $oxiid . '_box ' . OxiAddonsItemRows($styledata, 3) . ' ' . OxiAddonsAdminDefine($user) . '">
                        <div class="oxi_addons_content_box" ' . OxiAddonsAnimation($styledata, 75) . '>
                            <div class="oxi_addons_image_content">
                                <img src="' . OxiAddonsUrlConvert($data[1]) . '" alt="" class="oxi-image">
                                <div class="oxi_addons_image_button">
                                    <a href="' . OxiAddonsUrlConvert($data[9]) . '" class="oxi_addons_image_details oxi_addons_link">' . OxiAddonsTextConvert($data[7]) . '</a>
                                    <a href="' . OxiAddonsUrlConvert($data[13]) . '" class="oxi_addons_image_preview oxi_addons_link">' . OxiAddonsTextConvert($data[11]) . '</a>
                                </div>
                            </div>
                            <div class="oxi_addons_text_content">
                                <div class="oxi_addons_text_headding">' . OxiAddonsTextConvert($data[3]) . '</div>
                                <div class="oxi_addons_text_details">' . OxiAddonsTextConvert($data[5]) . '</div>
                            </div>
                        </div>';
        if ($user == 'admin') {
            echo'<div class="oxi-addons-admin-absulote">
                        <div class="oxi-addons-admin-absulate-edit">
                            <form method="post"> ' . wp_nonce_field("OxiAddonsListFileEditimage_boxesdata") . '
                                <input type="hidden" name="oxi-item-id" value="' . $value['id'] . '">
                                <button class="btn btn-primary" type="submit" value="edit" name="OxiAddonsListFileEdit">Edit</button>
                            </form>
                        </div>
                        <div class="oxi-addons-admin-absulate-delete">
                            <form method="post">  ' . wp_nonce_field("OxiAddonsListFileDeleteimage_boxesdata") . '
                                <input type="hidden" name="oxi-item-id" value="' . $value['id'] . '">
                                <button class="btn btn-danger " type="submit" value="delete" name="OxiAddonsListFileDelete">Delete</button>
                            </form>
                        </div>
                    </div>';
        }
        echo'</div>';
    }
    echo '</div>
        </div>';

    $css = '.oxi_addons_container_' . $oxiid . '_box {
                padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 47) . ';
            }
            .oxi_addons_container_' . $oxiid . '_box .oxi_addons_content_box{
                max-width: ' . $styledata[7] . 'px;
                margin: 0 auto;
                width: 100%;
                display: flex;
                flex-direction: column;
                border-width: ' . OxiAddonsPaddingMarginSanitize($styledata, 11) . ';
                border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 31) . ';
                border-color: ' . $styledata[28] . ';
                border-style: ' . $styledata[27] . ';
                overflow: hidden;
                ' . OxiAddonsBoxShadowSanitize($styledata, 63) . ';
                transition: all .3s linear;
            }
            .oxi_addons_container_' . $oxiid . '_box .oxi_addons_content_box:hover {
                ' . OxiAddonsBoxShadowSanitize($styledata, 69) . ';
            }
            .oxi_addons_container_' . $oxiid . '_box .oxi_addons_image_content{
                width: 100%;
                position: relative;
            }
            .oxi_addons_container_' . $oxiid . '_box .oxi_addons_image_content::after{
                content: "";
                display: block;
                padding-bottom: ' . ($styledata[289] / $styledata[7] * 100) . '%;
            }
            .oxi_addons_container_' . $oxiid . '_box .oxi_addons_image_content .oxi-image{
                width: 100%;
                height: 100%;
                position: absolute;
                top: 0;
                left: 0;
            }
            .oxi_addons_container_' . $oxiid . '_box .oxi_addons_image_button{
                width: 100%;
                height: 100%;
                position: absolute;
                top: 0;
                left: 0;
                display: flex;
                justify-content: center;
                align-items: center; 
                background: ' . $styledata[153] . ';
                opacity: 0;
            }
            .oxi_addons_container_' . $oxiid . '_box .oxi_addons_content_box:hover .oxi_addons_image_button {
                opacity: 1;
            } 
            .oxi_addons_container_' . $oxiid . '_box .oxi_addons_link{
                border-width: ' . OxiAddonsPaddingMarginSanitize($styledata, 155) . ';
                border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 171) . ';
                padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 203) . ';
                margin: ' . OxiAddonsPaddingMarginSanitize($styledata, 219) . ';
                text-transform: uppercase;
            }
            .oxi_addons_container_' . $oxiid . '_box .oxi_addons_link:hover{
                border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 187) . ';
            }
            .oxi_addons_container_' . $oxiid . '_box .oxi_addons_image_details{
                font-size: ' . $styledata[237] . 'px;
                color: ' . $styledata[241] . ';
                background: ' . $styledata[243] . ';
                border-color: ' . $styledata[246] . ';
                border-style: ' . $styledata[245] . ';
                ' . OxiAddonsFontSettings($styledata, 277) . ' 
            }
            .oxi_addons_container_' . $oxiid . '_box .oxi_addons_image_details:hover{
                color: ' . $styledata[249] . ';
                background: ' . $styledata[251] . ';
                border-color: ' . $styledata[253] . ';
                border-style: ' . $styledata[254] . ';
            }
            .oxi_addons_container_' . $oxiid . '_box .oxi_addons_image_preview{
                font-size: ' . $styledata[257] . 'px;
                color: ' . $styledata[261] . ';
                background: ' . $styledata[263] . ';
                border-color: ' . $styledata[266] . ';
                border-style: ' . $styledata[265] . ';
                ' . OxiAddonsFontSettings($styledata, 283) . ' 
            }
            .oxi_addons_container_' . $oxiid . '_box .oxi_addons_image_preview:hover{
                color: ' . $styledata[269] . ';
                background: ' . $styledata[271] . ';
                border-color: ' . $styledata[274] . ';
                border-style: ' . $styledata[273] . ';
            }
            .oxi_addons_container_' . $oxiid . '_box .oxi_addons_text_content{
                width: 100%;
                display: flex;
                flex-direction: column;
                justify-content: space-around;
                background: ' . $styledata[79] . ';
                padding:  ' . OxiAddonsPaddingMarginSanitize($styledata, 81) . ';
            }
            .oxi_addons_container_' . $oxiid . '_box .oxi_addons_text_headding{
                width: 100%;
                font-size: ' . $styledata[97] . 'px;
                color: ' . $styledata[101] . ';
                padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 109) . ';
                ' . OxiAddonsFontSettings($styledata, 103) . ' 
            }
            .oxi_addons_container_' . $oxiid . '_box .oxi_addons_text_details{
                width: 100%;
                font-size: ' . $styledata[125] . 'px;
                color: ' . $styledata[129] . ';
                padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 137) . ';
                ' . OxiAddonsFontSettings($styledata, 131) . ' 
            }
            @media only screen and (min-width : 669px) and (max-width : 993px){
                .oxi_addons_container_' . $oxiid . '_box {
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 48) . ';
                }
                .oxi_addons_container_' . $oxiid . '_box .oxi_addons_content_box{
                    max-width: ' . $styledata[8] . 'px;
                    border-width: ' . OxiAddonsPaddingMarginSanitize($styledata, 12) . ';
                    border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 32) . ';
                }
                .oxi_addons_container_' . $oxiid . '_box .oxi_addons_image_content::after{
                    padding-bottom: ' . ($styledata[290] / $styledata[8] * 100) . '%;
                }
                .oxi_addons_container_' . $oxiid . '_box .oxi_addons_link{
                    border-width: ' . OxiAddonsPaddingMarginSanitize($styledata, 156) . ';
                    border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 172) . ';
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 204) . ';
                    margin: ' . OxiAddonsPaddingMarginSanitize($styledata, 220) . ';
                }
                .oxi_addons_container_' . $oxiid . '_box .oxi_addons_link:hover{
                    border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 188) . ';
                }
                .oxi_addons_container_' . $oxiid . '_box .oxi_addons_image_details{
                    font-size: ' . $styledata[238] . 'px;
                }
                .oxi_addons_container_' . $oxiid . '_box .oxi_addons_image_preview{
                    font-size: ' . $styledata[258] . 'px;
                }
                .oxi_addons_container_' . $oxiid . '_box .oxi_addons_text_content{
                    padding:  ' . OxiAddonsPaddingMarginSanitize($styledata, 82) . ';
                }
                .oxi_addons_container_' . $oxiid . '_box .oxi_addons_text_headding{
                    font-size: ' . $styledata[98] . 'px;
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 110) . ';
                }
                .oxi_addons_container_' . $oxiid . '_box .oxi_addons_text_details{
                    font-size: ' . $styledata[126] . 'px;
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 138) . ';
                }  
            }
            @media only screen and (max-width : 668px){
                .oxi_addons_container_' . $oxiid . '_box {
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 49) . ';
                }
                .oxi_addons_container_' . $oxiid . '_box .oxi_addons_content_box{
                    max-width: ' . $styledata[9] . 'px;
                    border-width: ' . OxiAddonsPaddingMarginSanitize($styledata, 13) . ';
                    border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 33) . ';
                }
                .oxi_addons_container_' . $oxiid . '_box .oxi_addons_image_content::after{
                    padding-bottom: ' . ($styledata[291] / $styledata[9] * 100) . '%;
                }
                .oxi_addons_container_' . $oxiid . '_box .oxi_addons_link{
                    border-width: ' . OxiAddonsPaddingMarginSanitize($styledata, 157) . ';
                    border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 173) . ';
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 205) . ';
                    margin: ' . OxiAddonsPaddingMarginSanitize($styledata, 221) . ';
                }
                .oxi_addons_container_' . $oxiid . '_box .oxi_addons_link:hover{
                    border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 189) . ';
                }
                .oxi_addons_container_' . $oxiid . '_box .oxi_addons_image_details{
                    font-size: ' . $styledata[239] . 'px;
                }
                .oxi_addons_container_' . $oxiid . '_box .oxi_addons_image_preview{
                    font-size: ' . $styledata[259] . 'px;
                }
                .oxi_addons_container_' . $oxiid . '_box .oxi_addons_text_content{
                    padding:  ' . OxiAddonsPaddingMarginSanitize($styledata, 83) . ';
                }
                .oxi_addons_container_' . $oxiid . '_box .oxi_addons_text_headding{
                    font-size: ' . $styledata[99] . 'px;
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 111) . ';
                }
                .oxi_addons_container_' . $oxiid . '_box .oxi_addons_text_details{
                    font-size: ' . $styledata[127] . 'px;
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 139) . ';
                }
            }';
    echo OxiAddonsInlineCSSData($css);
}
