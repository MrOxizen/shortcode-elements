<?php
if (!defined('ABSPATH'))
    exit;
oxi_addons_user_capabilities();
global $wpdb;
$oxitype = sanitize_text_field($_GET['oxitype']);
$oxiid = (int) $_GET['styleid'];
$table_name = $wpdb->prefix . 'oxi_div_style';
$table_list = $wpdb->prefix . 'oxi_div_list';

if (!empty($_REQUEST['_wpnonce'])) {
    $nonce = $_REQUEST['_wpnonce'];
}
$listid = '';
$listitemdata = array("", "", "", "", "", "", "", "", "", "", "", "", "", "", "");

if (!empty($_POST['data-submit']) && $_POST['data-submit'] == 'Save') {
    if (!wp_verify_nonce($nonce, 'OxiAddCB-nonce')) {
        die('You do not have sufficient permissions to access this page.');
    } else {
        $data = 'oxi-addons-preview-BG |' . sanitize_text_field($_POST['oxi-addons-preview-BG']) . '|'
                . OxiAddonsADMHelpItemPerRowsSanitize('OxiAddIconBoxes-rows')
                . oxi_addons_adm_help_single_size('OxiAddCB-width')
                . oxi_addons_adm_help_padding_margin_senitize('oxiaddons_box_border_W')
                . OxiAddonsADMHelpBorderSanitize('oxiaddons_box_border').'|'
                . oxi_addons_adm_help_padding_margin_senitize('oxiaddons_box_border_R')
                . oxi_addons_adm_help_padding_margin_senitize('OxiAddCB-margin')
                . OxiAddonsADMBoxShadowSanitize('OxiAddCB-box-shadow')
                . OxiAddonsADMBoxShadowSanitize('OxiAddCB-box-Hover-shadow')
                . oxi_addons_adm_help_animation_senitize('OxiAddCB-animation')
                
                . 'oxiaddons_content_BG |' . sanitize_text_field($_POST['oxiaddons_content_BG']) . '|'
                . oxi_addons_adm_help_padding_margin_senitize('oxiaddons_content_padding')
                
                . oxi_addons_adm_help_single_size('OxiAddCB-heading-size')
                . ' OxiAddCB-heading-color |' . sanitize_hex_color($_POST['OxiAddCB-heading-color']) . '|'
                . OxiAddonsADMHelpFontSettingsSanitize('OxiAddCB-heading_font')
                . oxi_addons_adm_help_padding_margin_senitize('OxiAddCB-heading-padding')
                
                . oxi_addons_adm_help_single_size('OxiAddCB_details_size')
                . 'OxiAddCB_details_color |' . sanitize_hex_color($_POST['OxiAddCB_details_color']) . '|'
                . OxiAddonsADMHelpFontSettingsSanitize('OxiAddCB_details_font')
                . oxi_addons_adm_help_padding_margin_senitize('OxiAddCB_details_padding')
                
                . 'OxiAddCB_button_content_BG |' . sanitize_text_field($_POST['OxiAddCB_button_content_BG']) . '|'
                . oxi_addons_adm_help_padding_margin_senitize('OxiAddCB_button_border_W')
                . oxi_addons_adm_help_padding_margin_senitize('OxiAddCB_button_border_R')
                . oxi_addons_adm_help_padding_margin_senitize('OxiAddCB_button_H_border_R')
                . oxi_addons_adm_help_padding_margin_senitize('OxiAddCB_button_P')
                . oxi_addons_adm_help_padding_margin_senitize('OxiAddCB_button_M')
                . 'OxiAddCB_button_link_opening |' . sanitize_text_field($_POST['OxiAddCB_button_link_opening']) . '|'
                
                . oxi_addons_adm_help_single_size('OxiAddCB_button_one_size')
                . 'OxiAddCB_button_one_color |' . sanitize_hex_color($_POST['OxiAddCB_button_one_color']) . '|'
                . 'OxiAddCB_button_one_bg_color |' . sanitize_text_field($_POST['OxiAddCB_button_one_bg_color']) . '|'
                . OxiAddonsADMHelpBorderSanitize('OxiAddCB_button_one_border').'|'
                
                . 'OxiAddCB_button_one_H_color |' . sanitize_hex_color($_POST['OxiAddCB_button_one_H_color']) . '|'
                . 'OxiAddCB_button_one_H_bg_color |' . sanitize_text_field($_POST['OxiAddCB_button_one_H_bg_color']) . '|'
                . OxiAddonsADMHelpBorderSanitize('OxiAddCB_button_one_H_border').'|'
                
                . oxi_addons_adm_help_single_size('OxiAddCB_button_two_size')
                . 'OxiAddCB_button_two_color |' . sanitize_hex_color($_POST['OxiAddCB_button_two_color']) . '|'
                . 'OxiAddCB_button_two_bg_color |' . sanitize_text_field($_POST['OxiAddCB_button_two_bg_color']) . '|'
                . OxiAddonsADMHelpBorderSanitize('OxiAddCB_button_two_border').'|'
                
                . 'OxiAddCB_button_two_H_color |' . sanitize_hex_color($_POST['OxiAddCB_button_two_H_color']) . '|'
                . 'OxiAddCB_button_two_H_bg_color |' . sanitize_text_field($_POST['OxiAddCB_button_two_H_bg_color']) . '|'
                . OxiAddonsADMHelpBorderSanitize('OxiAddCB_button_two_H_border').'|'
                . OxiAddonsADMHelpFontSettingsSanitize('OxiAddCB_button_one_font')
                . OxiAddonsADMHelpFontSettingsSanitize('OxiAddCB_button_two_font')
                . oxi_addons_adm_help_single_size('OxiAddCB-Height')
                . '';
                
        $data = sanitize_text_field($data);
        $wpdb->query($wpdb->prepare("UPDATE $table_name SET css = %s WHERE id = %d", $data, $oxiid));
    }
}

if (!empty($_POST['OxiAddonsListFile']) && $_POST['OxiAddonsListFile'] == 'Submit') {
    if (!wp_verify_nonce($nonce, 'OxiAddonsListData-nonce')) {
        die('You do not have sufficient permissions to access this page.');
    } else {
        $oxilistid = (int) $_POST['oxilistid'];
        $data = ' OxiAddCB-Front-IMG ||#||' . OxiAddonsAdminUrlConvert($_POST['OxiAddCB-Front-IMG']) . '||#||'
                . 'OxiAddCB-heading-text ||#||' . OxiAddonsADMHelpTextSenitize($_POST['OxiAddCB-heading-text']) . '||#||'
                . 'OxiAddCB-content ||#||' . OxiAddonsADMHelpTextSenitize($_POST['OxiAddCB-content']) . '||#||'
                . 'oxiaddons_button_one_name ||#||' . OxiAddonsADMHelpTextSenitize($_POST['oxiaddons_button_one_name']) . '||#||'
                . 'oxiaddons_button_one_link ||#||' . OxiAddonsAdminUrlConvert($_POST['oxiaddons_button_one_link']) . '||#||'
                . 'oxiaddons_button_two_name ||#||' . OxiAddonsADMHelpTextSenitize($_POST['oxiaddons_button_two_name']) . '||#||'
                . 'oxiaddons_button_two_link ||#||' . OxiAddonsAdminUrlConvert($_POST['oxiaddons_button_two_link']) . '||#||'
                . '  ||#||';
        $data = sanitize_text_field($data);
        if ($oxilistid > 0) {
            $wpdb->query($wpdb->prepare("UPDATE $table_list SET files = %s WHERE id = %d", $data, $oxilistid));
        } else {
            $wpdb->query($wpdb->prepare("INSERT INTO {$table_list} (styleid, type, files) VALUES (%d, %s, %s )", array($oxiid, 'oxi-addons', $data)));
        }
    }
}
if (!empty($_POST['OxiAddonsListFileDelete']) && is_numeric($_POST['oxi-item-id'])) {
    if (!wp_verify_nonce($nonce, 'OxiAddonsListFileDelete' . $oxitype . 'data')) {
        die('You do not have sufficient permissions to access this page.');
    } else {
        $item_id = (int) $_POST['oxi-item-id'];
        $wpdb->query($wpdb->prepare("DELETE FROM {$table_list} WHERE id = %d ", $item_id));
    }
}
if (!empty($_POST['OxiAddonsListFileEdit']) && is_numeric($_POST['oxi-item-id'])) {
    if (!wp_verify_nonce($nonce, 'OxiAddonsListFileEdit' . $oxitype . 'data')) {
        die('You do not have sufficient permissions to access this page.');
    } else {
        $item_id = (int) $_POST['oxi-item-id'];
        $data = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_list WHERE id = %d ", $item_id), ARRAY_A);
        $listitemdata = explode('||#||', $data['files']);
        $listid = $data['id'];
        echo '<script type="text/javascript"> jQuery(document).ready(function () {setTimeout(function() { jQuery("#oxi-addons-list-data-modal").modal("show")  }, 500); });</script>';
    }
}
OxiDataAdminStyleNameChange();
$style = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d ", $oxiid), ARRAY_A);

$listdata = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_list WHERE styleid = %d ", $oxiid), ARRAY_A);
$stylefiles = explode('||#||', $style['css']);
$styledata = explode('|', $stylefiles[0]);
// echo '<pre>';
// print_r($styledata);
// echo '</pre>';
?>
<div class="wrap">
    <?php echo OxiAddonsAdmAdminMenu($oxitype, '', '', ''); ?>
    <div class="oxi-addons-wrapper">
        <div class="oxi-addons-row">
            <div class="oxi-addons-style-20-spacer"></div>
            <div class="oxi-addons-style-left">
                <form method="post" id="oxi-addons-form-submit">
                    <div class="oxi-addons-style-settings">
                        <div class="oxi-addons-tabs-wrapper">
                            <ul class="oxi-addons-tabs-ul">
                                <li ref="#oxi-addons-tabs-1">General Setting</li>
                                <li ref="#oxi-addons-tabs-2">Button</li>
                            </ul>
                            <div class="oxi-addons-tabs-content-tabs" id="oxi-addons-tabs-1">
                                <div class="oxi-addons-col-6">
                                    <div class="oxi-addons-content-div">
                                        <div class="oxi-head">
                                            General Settings
                                        </div>
                                        <div class="oxi-addons-content-div-body">
                                            <?php
                                            echo OxiAddonsADMHelpItemPerRows('OxiAddIconBoxes-rows', $styledata, 3, 'false', '.oxi_addons_container_box');
                                            echo oxi_addons_adm_help_number_dtm('OxiAddCB-width', $styledata[7], $styledata[8], $styledata[9], 1, 'Width', 'Set Your Content Boxes Max Width', 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_content_box', 'max-width');
                                            echo oxi_addons_adm_help_number_dtm('OxiAddCB-Height', $styledata[289], $styledata[290], $styledata[291], 1, 'Height', 'Set Your Content Boxes Height', 'true', '.oxi_addons_container_' . $oxiid . '_box .oxi_addons_image_content::after', 'padding-bottom');
                                            echo oxi_addons_adm_help_MiniColor('oxiaddons_content_BG', $styledata[79], 'rgba', 'Background Color', 'Select Your Background Color', 'false', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_text_content', 'background');
                                            echo oxi_addons_adm_help_padding_margin('oxiaddons_box_border_W', 11, $styledata, 1, 'Border Width', 'Set you border Width', 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_content_box', 'border-width');
                                            echo OxiAddonsADMhelpBorder('oxiaddons_box_border', 27, $styledata, 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_content_box', 'style');
                                            echo oxi_addons_adm_help_padding_margin('oxiaddons_box_border_R', 31, $styledata, 1, 'Border Radius', 'Set you border Radius', 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_content_box', 'border-radius');
                                            echo oxi_addons_adm_help_padding_margin('oxiaddons_content_padding', 81, $styledata, 1, 'Padding', 'Set Your All Content  Padding', 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_text_content', 'padding');
                                            echo oxi_addons_adm_help_padding_margin('OxiAddCB-margin', 47, $styledata, 1, 'Margin', 'Set Your Content Boxes  Margin', 'true', '.oxi_addons_container_'.$oxiid.'_box', 'padding');
                                            ?>
                                        </div>
                                        <div class="oxi-head">
                                            Box Shadow
                                        </div>
                                        <div class="oxi-addons-content-div-body">
                                            <?php
                                            echo OxiAddonsADMhelpBoxShadow('OxiAddCB-box-shadow', 63, $styledata, 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_content_box');
                                            ?>
                                        </div>
                                        <div class="oxi-head">
                                            Hover Box Shadow
                                        </div>
                                        <div class="oxi-addons-content-div-body">
                                            <?php
                                            echo OxiAddonsADMhelpBoxShadow('OxiAddCB-box-Hover-shadow', 69, $styledata, 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_content_box:hover');
                                            ?>
                                        </div>
                                        
                                    </div>
                                    <div class="oxi-addons-content-div">
                                        <div class="oxi-head">
                                            Animation
                                        </div>
                                        <div class="oxi-addons-content-div-body">
                                            <?php
                                            echo oxi_addons_adm_help_Animation('OxiAddCB-animation', 75, $styledata, 'true', '.oxi-addons-content-boxes-' . $oxiid . '');
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="oxi-addons-col-6">
                                    <div class="oxi-addons-content-div">
                                        <div class="oxi-head">
                                            Heading Settings
                                        </div>
                                        <div class="oxi-addons-content-div-body">
                                            <?php
                                            echo oxi_addons_adm_help_number_dtm('OxiAddCB-heading-size', $styledata[97], $styledata[98], $styledata[99], 1, 'Font Size', 'Select Your Heading Font Size', 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_text_headding', 'font-size');
                                            echo oxi_addons_adm_help_MiniColor('OxiAddCB-heading-color', $styledata[101], '', 'Color', 'Select Your Heading Color', 'false', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_text_headding', 'color');
                                            echo OxiAddonsADMHelpFontSettings('OxiAddCB-heading_font', 103, $styledata, 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_text_headding');
                                            echo oxi_addons_adm_help_padding_margin('OxiAddCB-heading-padding', 109, $styledata, 1, 'Padding', 'Set Your Heading Padding', 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_text_headding', 'padding');
                                            ?>
                                        </div>
                                    </div>

                                    <div class="oxi-addons-content-div">
                                        <div class="oxi-head">
                                            Details Settings
                                        </div>
                                        <div class="oxi-addons-content-div-body">
                                            <?php
                                            echo oxi_addons_adm_help_number_dtm('OxiAddCB_details_size', $styledata[125], $styledata[126], $styledata[127], 1, 'Font Size', 'Select Your Content Font Size', 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_text_details', 'font-size');
                                            echo oxi_addons_adm_help_MiniColor('OxiAddCB_details_color', $styledata[129], '', 'Color', 'Select Your Content Color', 'false', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_text_details', 'color');
                                            echo OxiAddonsADMHelpFontSettings('OxiAddCB_details_font', 131, $styledata, 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_text_details');
                                            echo oxi_addons_adm_help_padding_margin('OxiAddCB_details_padding', 137, $styledata, 1, 'padding', 'Set Your Content Padding', 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_text_details', 'Padding');
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="oxi-addons-tabs-content-tabs" id="oxi-addons-tabs-2">
                                <div class="oxi-addons-col-6">
                                    <div class="oxi-addons-content-div">
                                    <div class="oxi-head">
                                            Button Settings
                                        </div>
                                        <div class="oxi-addons-content-div-body">
                                            <?php
                                            echo oxi_addons_adm_help_MiniColor('OxiAddCB_button_content_BG', $styledata[153], 'rgba', 'Hover Overlay Color', 'Select Your Content Color', 'f', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_image_button', 'background');
                                            echo oxi_addons_adm_help_padding_margin('OxiAddCB_button_border_W', 155, $styledata, 1, 'Border Width', 'Set you border Width', 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_link', 'border-width');
                                            echo oxi_addons_adm_help_padding_margin('OxiAddCB_button_border_R', 171, $styledata, 1, 'Border Radius', 'Set you border Radius', 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_link', 'border-radius');
                                            echo oxi_addons_adm_help_padding_margin('OxiAddCB_button_H_border_R', 187, $styledata, 1, 'Hover Border Radius', 'Set you border Radius', 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_link:hover', 'border-radius');
                                            echo oxi_addons_adm_help_padding_margin('OxiAddCB_button_P', 203, $styledata, 1, 'Padding', 'Set Your Content Button  Padding', 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_link', 'padding');
                                            echo oxi_addons_adm_help_padding_margin('OxiAddCB_button_M', 219, $styledata, 1, 'Margin', 'Set Your Content Button Margin', 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_link', 'margin');
                                            echo oxi_addons_adm_help_true_false('OxiAddCB_button_link_opening', $styledata[235], 'Normal', '', 'New Tab', '_blank', 'Link Opening', 'Select the Link Opening type', 'true');
                                            ?>
                                        </div>
                                        <div class="oxi-head">
                                            Button One Settings
                                        </div>
                                        <div class="oxi-addons-content-div-body">
                                            <?php
                                            echo oxi_addons_adm_help_number_dtm('OxiAddCB_button_one_size', $styledata[237], $styledata[238], $styledata[239], 1, 'Font Size', 'Select Your Content Font Size', 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_image_details', 'font-size');
                                            echo oxi_addons_adm_help_MiniColor('OxiAddCB_button_one_color', $styledata[241], '', 'Color', 'Select Your Content Color', 'false', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_image_details', 'color');
                                            echo oxi_addons_adm_help_MiniColor('OxiAddCB_button_one_bg_color', $styledata[243], 'rgba', 'Background Color', 'Select Your Content Color', 'false', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_image_details', 'background');
                                            echo OxiAddonsADMHelpFontSettings('OxiAddCB_button_one_font', 277, $styledata, 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_image_details');
                                            echo OxiAddonsADMhelpBorder('OxiAddCB_button_one_border', 245, $styledata, 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_image_details', 'style');
                                            ?>
                                        </div>
                                        <div class="oxi-head">
                                            Button One Hover Settings
                                        </div>
                                        <div class="oxi-addons-content-div-body">
                                            <?php
                                            echo oxi_addons_adm_help_MiniColor('OxiAddCB_button_one_H_color', $styledata[249], '', 'Color', 'Select Your Content Color', 'false', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_image_details:hover', 'color');
                                            echo oxi_addons_adm_help_MiniColor('OxiAddCB_button_one_H_bg_color', $styledata[251], 'rgba', ' Backgound Color', 'Select Your Content Color', 'false', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_image_details:hover', 'background');
                                            echo OxiAddonsADMhelpBorder('OxiAddCB_button_one_H_border', 253, $styledata, 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_image_details:hover', 'style');
                                            ?>
                                        </div>    
                                    </div>
                                </div>
                                <div class="oxi-addons-col-6">
                                    <div class="oxi-addons-content-div">
                                        <div class="oxi-head">
                                            Button Two Settings
                                        </div>
                                        <div class="oxi-addons-content-div-body">
                                            <?php
                                            echo oxi_addons_adm_help_number_dtm('OxiAddCB_button_two_size', $styledata[257], $styledata[258], $styledata[259], 1, 'Font Size', 'Select Your Content Font Size', 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_image_preview', 'font-size');
                                            echo oxi_addons_adm_help_MiniColor('OxiAddCB_button_two_color', $styledata[261], '', 'Color', 'Select Your Content Color', 'false', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_image_preview', 'color');
                                            echo oxi_addons_adm_help_MiniColor('OxiAddCB_button_two_bg_color', $styledata[263], 'rgba', 'Backgound Color', 'Select Your Content Color', 'false', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_image_preview', 'background');
                                            echo OxiAddonsADMHelpFontSettings('OxiAddCB_button_two_font', 283, $styledata, 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_image_preview');
                                            echo OxiAddonsADMhelpBorder('OxiAddCB_button_two_border', 265, $styledata, 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_image_preview', 'style');
                                            ?>
                                        </div>
                                        <div class="oxi-head">
                                            Button Two Hover Settings
                                        </div>
                                        <div class="oxi-addons-content-div-body">
                                            <?php
                                            echo oxi_addons_adm_help_MiniColor('OxiAddCB_button_two_H_color', $styledata[269], '', 'Color', 'Select Your Content Color', 'false', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_image_preview:hover', 'color');
                                            echo oxi_addons_adm_help_MiniColor('OxiAddCB_button_two_H_bg_color', $styledata[271], 'rgba', 'Backgound Color', 'Select Your Content Color', 'false', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_image_preview:hover', 'background');
                                            echo OxiAddonsADMhelpBorder('OxiAddCB_button_two_H_border', 273, $styledata, 'true', '.oxi_addons_container_'.$oxiid.'_box .oxi_addons_image_preview:hover', 'style');
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="oxi-addons-setting-save">
                            <?php echo oxiaddonssettingsavedtmmode(); ?>
                            <button type="button" class="btn btn-danger" id="oxi-addons-setting-reload">Reset</button>
                            <input type="hidden" id="oxi-addons-preview-BG" name="oxi-addons-preview-BG" value="<?php echo $styledata[1]; ?>">
                            <input type="submit" class="btn btn-success" name="data-submit" value="Save">
                            <?php wp_nonce_field("OxiAddCB-nonce") ?>
                        </div>

                    </div>

                </form>
            </div>
            <div class="oxi-addons-style-right">
                <?php
                echo oxi_addons_list_modal_open();
                echo oxi_addons_shortcode_namechange($oxiid, $style['name']);
                echo oxi_addons_shortcode_call($oxitype, $oxiid);
                echo oxi_addons_list_rearrange('Image Boxes Rearrange', $listdata, 3, 'title');
                ?>
            </div>
            <div class="oxi-addons-style-left-preview">
                <div class="oxi-addons-style-left-preview-heading">
                    <div class="oxi-addons-style-left-preview-heading-left">
                        Preview
                    </div>
                    <div class="oxi-addons-style-left-preview-heading-right">
                        <?php echo oxi_addons_adm_help_preview_color($styledata[1]); ?>
                    </div>
                </div>
                <div class="oxi-addons-preview-data" id="oxi-addons-preview-data">
                    <?php echo oxi_image_boxes_style_5_shortcode($style, $listdata, 'admin') ?>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="oxi-addons-list-data-modal">
    <form method="post">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Data Settings</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <?php
                    echo oxi_addons_adm_help_modal_second_image_upload('OxiAddCB-Front-IMG', $listitemdata[1], 'Front-Image', 'Upload your content boxes images');
                    echo oxi_addons_adm_help_modal_textbox('OxiAddCB-heading-text', $listitemdata[3], 'Heading text', 'Set your heading text');
                    echo oxi_addons_adm_help_modal_textarea('OxiAddCB-content', $listitemdata[5], 'Content', 'Write your content box short details', 'false');
                    echo oxi_addons_adm_help_modal_textbox('oxiaddons_button_one_name', $listitemdata[7], 'Button one text', 'Set your button one text');
                    echo oxi_addons_adm_help_modal_textbox('oxiaddons_button_one_link', $listitemdata[9], 'Button one link', 'Set your button one link');
                    echo oxi_addons_adm_help_modal_textbox('oxiaddons_button_two_name', $listitemdata[11], 'Button two text', 'Set your button two text');
                    echo oxi_addons_adm_help_modal_textbox('oxiaddons_button_two_link', $listitemdata[13], 'Button two link', 'Set your button two link');
                    ?>
                </div>
                <div class="modal-footer">
                    <input type="hidden" id="oxilistid" name="oxilistid" value="<?php echo $listid; ?>">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <input type="submit" class="btn btn-success" name="OxiAddonsListFile" id="OxiAddonsListFile" value="Submit">
                    <?php wp_nonce_field("OxiAddonsListData-nonce") ?>
                </div>
            </div>
        </div>
    </form>
</div>