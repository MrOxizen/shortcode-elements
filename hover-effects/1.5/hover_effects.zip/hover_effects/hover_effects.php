

<?php
if (!defined('ABSPATH')) {
    exit;
}

$oxitype = sanitize_text_field($_GET['oxitype']);
$oxiimpport = '';
if (!empty($_GET['oxiimpport'])) {
    $oxiimpport = sanitize_text_field($_GET['oxiimpport']);
}

oxi_addons_user_capabilities();
OxiDataAdminImport($oxitype);
global $wpdb;
$table_name = $wpdb->prefix . 'oxi_div_style';
$table_import = $wpdb->prefix . 'oxi_div_import';
$importstyle = $wpdb->get_results("SELECT * FROM $table_import WHERE type = '$oxitype' ORDER BY id DESC", ARRAY_A);
$freeimport = array('style-1', 'style-2', 'style-3', 'style-4');
if (count($importstyle) < 1) {
    foreach ($freeimport as $value) {
        $wpdb->query($wpdb->prepare("INSERT INTO {$table_import} (type, name) VALUES (%s, %s )", array($oxitype, $value)));
    }
    $js = 'location.reload();';
    wp_add_inline_script('oxi-addons-vendor', $js);
}

$file = Array(
    'Style 1OXIIMPORThover_effectsOXIIMPORTstyle-1OXIIMPORToxi-addons-preview-BG || ||image-alignments|justify-content: center;|OxiAdmin-Item |oxi-addons-lg-col-1|oxi-addons-md-col-1|oxi-addons-xs-col-1| OxiAddCB-button-link-opening ||OxiAdmin-padding-top |20|20|20|OxiAdmin-padding-bottom |20|20|20|OxiAdmin-padding-left |20|20|20|OxiAdmin-padding-right |20|20|20|OxiAdmin-margin-top |3|3|3|OxiAdmin-margin-bottom |3|3|3|OxiAdmin-margin-left |3|3|3|OxiAdmin-margin-right |3|3|3|OxiAdmin-animation||2:false:false:500:10:0.2|0//|OxiAdmin-box-shadow |rgba(224, 224, 224, 0.74)|0|0|3|1||OxiAdmin-hover-box-shadow |rgba(109, 3, 222, 0.49)|0|0|3|1|| OxiAdmin-width |250| OxiAdmin-height|250|OxiAdmin-I-bg|rgba(112, 3, 222, 1)|||OxiAdmin-border-radius-top |0|0|0|OxiAdmin-border-radius-bottom |0|0|0|OxiAdmin-border-radius-left |0|0|0|OxiAdmin-border-radius-right |0|0|0|OxiAdmin-hover-border-radius-top |0|0|0|OxiAdmin-hover-border-radius-bottom |0|0|0|OxiAdmin-hover-border-radius-left |0|0|0|OxiAdmin-hover-border-radius-right |0|0|0|OxiAdmin-button-size |14|14|14||||| OxiAdmin-button-color |#9100bd| OxiAdmin-button-bgcolor |rgba(255, 255, 255, 1)|OxiAdmin-button-border-top |0|0|0|OxiAdmin-button-border-bottom |0|0|0|OxiAdmin-button-border-left |0|0|0|OxiAdmin-button-border-right |0|0|0|OxiAdmin-button-border |solid|#ffffff||OxiAdmin-button-radius-top |50|50|50|OxiAdmin-button-radius-bottom |50|50|50|OxiAdmin-button-radius-left |50|50|50|OxiAdmin-button-radius-right |50|50|50|OxiAdmin-button-margin-top |3|3|3|OxiAdmin-button-margin-bottom |3|3|3|OxiAdmin-button-margin-left |3|3|3|OxiAdmin-button-margin-right |3|3|3| OxiAdmin-button-hover-color |#ffffff| OxiAdmin-button-hover-bgcolor |rgba(145, 0, 189, 0.81)|OxiAdmin-hover-button-border |solid|#ffffff||OxiAdmin-hover-button-radius-top |50|50|50|OxiAdmin-hover-button-radius-bottom |50|50|50|OxiAdmin-hover-button-radius-left |50|50|50|OxiAdmin-hover-button-radius-right |50|50|50|OxiAdmin-button-padding-top |8|8|8|OxiAdmin-button-padding-bottom |8|8|8|OxiAdmin-button-padding-left |12|12|12|OxiAdmin-button-padding-right |12|12|12|OxiAdmin-button-family |Open+Sans|600|OxiAdmin-button-style |normal:1.3|center:0()0()0()#ffffff:1| button-animation |ihewc-fade-up| title-animation |ihewc-fade-up|OxiAdmin-title-size |20|20|20| OxiAdmin-title-color |#ffffff|OxiAdmin-title-family |Open+Sans|600|OxiAdmin-title-style |normal:1.3|center:0()0()0()#ffffff:1|OxiAdmin-title-margin-top |2|2|2|OxiAdmin-title-margin-bottom |7|7|7|OxiAdmin-title-margin-left |2|2|2|OxiAdmin-title-margin-right |2|2|2| content-animation |ihewc-fade-up|OxiAdmin-content-size |16|16|16| OxiAdmin-content-color |#ffffff|OxiAdmin-content-family |Open+Sans|600|OxiAdmin-content-style |normal:1.3|center:0()0()0()#ffffff:1|OxiAdmin-content-margin-top |3|3|3|OxiAdmin-content-margin-bottom |3|3|3|OxiAdmin-content-margin-left |3|3|3|OxiAdmin-content-margin-right |3|3|3|OxiAdmin-title-underline-size |120|120|120|OxiAdmin-title-underline-height |0|0|0|OxiAdmin-title-underline |solid|#e300a3||OxiAdmin-underline-margin-top |0|0|0|OxiAdmin-underline-margin-bottom |3|3|3|OxiAdmin-underline-margin-left |0|0|0|OxiAdmin-underline-margin-right |0|0|0||||#|| ||#|||##OXISTYLE##OxiAdmin-file-first-icon||#||Image Hover Title||#||OxiAdmin-file-desc||#||Add Your Description Unless make it blank.||#||OxiAdmin-file-button-text||#||Buy Now||#||OxiAdmin-file-hover-link||#||#||#||OxiAdmin-file-image||#||OxiAddonsUrl.//wp-content/uploads/2019/05/6.jpg||#||||#|| ||#||##OXIDATA##',
    'Style 2 <span> 4 effects</span>OXIIMPORThover_effectsOXIIMPORTstyle-2OXIIMPORToxi-addons-preview-BG || ||image-alignments|justify-content: center;|OxiAdmin-Item |oxi-addons-lg-col-1|oxi-addons-md-col-1|oxi-addons-xs-col-1| OxiAddCB-button-link-opening ||OxiAdmin-padding-top |20|20|20|OxiAdmin-padding-bottom |20|20|20|OxiAdmin-padding-left |20|20|20|OxiAdmin-padding-right |20|20|20|OxiAdmin-margin-top |3|3|3|OxiAdmin-margin-bottom |3|3|3|OxiAdmin-margin-left |3|3|3|OxiAdmin-margin-right |3|3|3|OxiAdmin-animation||2:false:false:500:10:0.2|0//|OxiAdmin-box-shadow |rgba(224, 224, 224, 0.74)|0|0|3|1||OxiAdmin-hover-box-shadow |rgba(109, 3, 222, 0.49)|0|0|3|1|| OxiAdmin-width |250| OxiAdmin-height|250|OxiAdmin-I-bg|rgba(112, 3, 222, 1)|||OxiAdmin-border-radius-top |0|0|0|OxiAdmin-border-radius-bottom |0|0|0|OxiAdmin-border-radius-left |0|0|0|OxiAdmin-border-radius-right |0|0|0|OxiAdmin-hover-border-radius-top |0|0|0|OxiAdmin-hover-border-radius-bottom |0|0|0|OxiAdmin-hover-border-radius-left |0|0|0|OxiAdmin-hover-border-radius-right |0|0|0|OxiAdmin-button-size |14|14|14||||| OxiAdmin-button-color |#9100bd| OxiAdmin-button-bgcolor |rgba(255, 255, 255, 1)|OxiAdmin-button-border-top |0|0|0|OxiAdmin-button-border-bottom |0|0|0|OxiAdmin-button-border-left |0|0|0|OxiAdmin-button-border-right |0|0|0|OxiAdmin-button-border |solid|#ffffff||OxiAdmin-button-radius-top |50|50|50|OxiAdmin-button-radius-bottom |50|50|50|OxiAdmin-button-radius-left |50|50|50|OxiAdmin-button-radius-right |50|50|50|OxiAdmin-button-margin-top |3|3|3|OxiAdmin-button-margin-bottom |3|3|3|OxiAdmin-button-margin-left |3|3|3|OxiAdmin-button-margin-right |3|3|3| OxiAdmin-button-hover-color |#ffffff| OxiAdmin-button-hover-bgcolor |rgba(145, 0, 189, 0.81)|OxiAdmin-hover-button-border |solid|#ffffff||OxiAdmin-hover-button-radius-top |50|50|50|OxiAdmin-hover-button-radius-bottom |50|50|50|OxiAdmin-hover-button-radius-left |50|50|50|OxiAdmin-hover-button-radius-right |50|50|50|OxiAdmin-button-padding-top |8|8|8|OxiAdmin-button-padding-bottom |8|8|8|OxiAdmin-button-padding-left |12|12|12|OxiAdmin-button-padding-right |12|12|12|OxiAdmin-button-family |Open+Sans|600|OxiAdmin-button-style |normal:1.3|center:0()0()0()#ffffff:1| button-animation |ihewc-fade-up| title-animation |ihewc-fade-up|OxiAdmin-title-size |20|20|20| OxiAdmin-title-color |#ffffff|OxiAdmin-title-family |Open+Sans|600|OxiAdmin-title-style |normal:1.3|center:0()0()0()#ffffff:1|OxiAdmin-title-margin-top |2|2|2|OxiAdmin-title-margin-bottom |7|7|7|OxiAdmin-title-margin-left |2|2|2|OxiAdmin-title-margin-right |2|2|2| content-animation |ihewc-fade-up|OxiAdmin-content-size |16|16|16| OxiAdmin-content-color |#ffffff|OxiAdmin-content-family |Open+Sans|600|OxiAdmin-content-style |normal:1.3|center:0()0()0()#ffffff:1|OxiAdmin-content-margin-top |3|3|3|OxiAdmin-content-margin-bottom |3|3|3|OxiAdmin-content-margin-left |3|3|3|OxiAdmin-content-margin-right |3|3|3|OxiAdmin-title-underline-size |120|120|120|OxiAdmin-title-underline-height |0|0|0|OxiAdmin-title-underline |solid|#e300a3||OxiAdmin-underline-margin-top |0|0|0|OxiAdmin-underline-margin-bottom |3|3|3|OxiAdmin-underline-margin-left |0|0|0|OxiAdmin-underline-margin-right |0|0|0||||#|| ||#|||##OXISTYLE##OxiAdmin-file-first-icon||#||Image Hover Title||#||OxiAdmin-file-desc||#||Add Your Description Unless make it blank.||#||OxiAdmin-file-button-text||#||Buy Now||#||OxiAdmin-file-hover-link||#||#||#||OxiAdmin-file-image||#||OxiAddonsUrl.//wp-content/uploads/2019/05/6.jpg||#||||#|| ||#||##OXIDATA##',
    'Style 3 <span> 4 effects</span>OXIIMPORThover_effectsOXIIMPORTstyle-3OXIIMPORToxi-addons-preview-BG || ||image-alignments|justify-content: center;|OxiAdmin-Item |oxi-addons-lg-col-1|oxi-addons-md-col-1|oxi-addons-xs-col-1| OxiAddCB-button-link-opening ||OxiAdmin-padding-top |20|20|20|OxiAdmin-padding-bottom |20|20|20|OxiAdmin-padding-left |20|20|20|OxiAdmin-padding-right |20|20|20|OxiAdmin-margin-top |3|3|3|OxiAdmin-margin-bottom |3|3|3|OxiAdmin-margin-left |3|3|3|OxiAdmin-margin-right |3|3|3|OxiAdmin-animation||2:false:false:500:10:0.2|0//|OxiAdmin-box-shadow |rgba(224, 224, 224, 0.74)|0|0|3|1||OxiAdmin-hover-box-shadow |rgba(109, 3, 222, 0.49)|0|0|3|1|| OxiAdmin-width |250| OxiAdmin-height|250|OxiAdmin-I-bg|rgba(112, 3, 222, 1)|||OxiAdmin-border-radius-top |0|0|0|OxiAdmin-border-radius-bottom |0|0|0|OxiAdmin-border-radius-left |0|0|0|OxiAdmin-border-radius-right |0|0|0|OxiAdmin-hover-border-radius-top |0|0|0|OxiAdmin-hover-border-radius-bottom |0|0|0|OxiAdmin-hover-border-radius-left |0|0|0|OxiAdmin-hover-border-radius-right |0|0|0|OxiAdmin-button-size |14|14|14||||| OxiAdmin-button-color |#9100bd| OxiAdmin-button-bgcolor |rgba(255, 255, 255, 1)|OxiAdmin-button-border-top |0|0|0|OxiAdmin-button-border-bottom |0|0|0|OxiAdmin-button-border-left |0|0|0|OxiAdmin-button-border-right |0|0|0|OxiAdmin-button-border |solid|#ffffff||OxiAdmin-button-radius-top |50|50|50|OxiAdmin-button-radius-bottom |50|50|50|OxiAdmin-button-radius-left |50|50|50|OxiAdmin-button-radius-right |50|50|50|OxiAdmin-button-margin-top |3|3|3|OxiAdmin-button-margin-bottom |3|3|3|OxiAdmin-button-margin-left |3|3|3|OxiAdmin-button-margin-right |3|3|3| OxiAdmin-button-hover-color |#ffffff| OxiAdmin-button-hover-bgcolor |rgba(145, 0, 189, 0.81)|OxiAdmin-hover-button-border |solid|#ffffff||OxiAdmin-hover-button-radius-top |50|50|50|OxiAdmin-hover-button-radius-bottom |50|50|50|OxiAdmin-hover-button-radius-left |50|50|50|OxiAdmin-hover-button-radius-right |50|50|50|OxiAdmin-button-padding-top |8|8|8|OxiAdmin-button-padding-bottom |8|8|8|OxiAdmin-button-padding-left |12|12|12|OxiAdmin-button-padding-right |12|12|12|OxiAdmin-button-family |Open+Sans|600|OxiAdmin-button-style |normal:1.3|center:0()0()0()#ffffff:1| button-animation |ihewc-fade-up| title-animation |ihewc-fade-up|OxiAdmin-title-size |20|20|20| OxiAdmin-title-color |#ffffff|OxiAdmin-title-family |Open+Sans|600|OxiAdmin-title-style |normal:1.3|center:0()0()0()#ffffff:1|OxiAdmin-title-margin-top |2|2|2|OxiAdmin-title-margin-bottom |7|7|7|OxiAdmin-title-margin-left |2|2|2|OxiAdmin-title-margin-right |2|2|2| content-animation |ihewc-fade-up|OxiAdmin-content-size |16|16|16| OxiAdmin-content-color |#ffffff|OxiAdmin-content-family |Open+Sans|600|OxiAdmin-content-style |normal:1.3|center:0()0()0()#ffffff:1|OxiAdmin-content-margin-top |3|3|3|OxiAdmin-content-margin-bottom |3|3|3|OxiAdmin-content-margin-left |3|3|3|OxiAdmin-content-margin-right |3|3|3|OxiAdmin-title-underline-size |120|120|120|OxiAdmin-title-underline-height |0|0|0|OxiAdmin-title-underline |solid|#e300a3||OxiAdmin-underline-margin-top |0|0|0|OxiAdmin-underline-margin-bottom |3|3|3|OxiAdmin-underline-margin-left |0|0|0|OxiAdmin-underline-margin-right |0|0|0||||#|| ||#|||##OXISTYLE##OxiAdmin-file-first-icon||#||Image Hover Title||#||OxiAdmin-file-desc||#||Add Your Description Unless make it blank.||#||OxiAdmin-file-button-text||#||Buy Now||#||OxiAdmin-file-hover-link||#||#||#||OxiAdmin-file-image||#||OxiAddonsUrl.//wp-content/uploads/2019/05/6.jpg||#||||#|| ||#||##OXIDATA##',
    'Style 4 <span> 4 effects</span>OXIIMPORThover_effectsOXIIMPORTstyle-4OXIIMPORToxi-addons-preview-BG || ||image-alignments|justify-content: center;|OxiAdmin-Item |oxi-addons-lg-col-1|oxi-addons-md-col-1|oxi-addons-xs-col-1| OxiAddCB-button-link-opening ||OxiAdmin-padding-top |20|20|20|OxiAdmin-padding-bottom |20|20|20|OxiAdmin-padding-left |20|20|20|OxiAdmin-padding-right |20|20|20|OxiAdmin-margin-top |3|3|3|OxiAdmin-margin-bottom |3|3|3|OxiAdmin-margin-left |3|3|3|OxiAdmin-margin-right |3|3|3|OxiAdmin-animation||2:false:false:500:10:0.2|0//|OxiAdmin-box-shadow |rgba(224, 224, 224, 0.74)|0|0|3|1||OxiAdmin-hover-box-shadow |rgba(109, 3, 222, 0.49)|0|0|3|1|| OxiAdmin-width |250| OxiAdmin-height|250|OxiAdmin-I-bg|rgba(112, 3, 222, 1)|||OxiAdmin-border-radius-top |0|0|0|OxiAdmin-border-radius-bottom |0|0|0|OxiAdmin-border-radius-left |0|0|0|OxiAdmin-border-radius-right |0|0|0|OxiAdmin-hover-border-radius-top |0|0|0|OxiAdmin-hover-border-radius-bottom |0|0|0|OxiAdmin-hover-border-radius-left |0|0|0|OxiAdmin-hover-border-radius-right |0|0|0|OxiAdmin-button-size |14|14|14||||| OxiAdmin-button-color |#9100bd| OxiAdmin-button-bgcolor |rgba(255, 255, 255, 1)|OxiAdmin-button-border-top |0|0|0|OxiAdmin-button-border-bottom |0|0|0|OxiAdmin-button-border-left |0|0|0|OxiAdmin-button-border-right |0|0|0|OxiAdmin-button-border |solid|#ffffff||OxiAdmin-button-radius-top |50|50|50|OxiAdmin-button-radius-bottom |50|50|50|OxiAdmin-button-radius-left |50|50|50|OxiAdmin-button-radius-right |50|50|50|OxiAdmin-button-margin-top |3|3|3|OxiAdmin-button-margin-bottom |3|3|3|OxiAdmin-button-margin-left |3|3|3|OxiAdmin-button-margin-right |3|3|3| OxiAdmin-button-hover-color |#ffffff| OxiAdmin-button-hover-bgcolor |rgba(145, 0, 189, 0.81)|OxiAdmin-hover-button-border |solid|#ffffff||OxiAdmin-hover-button-radius-top |50|50|50|OxiAdmin-hover-button-radius-bottom |50|50|50|OxiAdmin-hover-button-radius-left |50|50|50|OxiAdmin-hover-button-radius-right |50|50|50|OxiAdmin-button-padding-top |8|8|8|OxiAdmin-button-padding-bottom |8|8|8|OxiAdmin-button-padding-left |12|12|12|OxiAdmin-button-padding-right |12|12|12|OxiAdmin-button-family |Open+Sans|600|OxiAdmin-button-style |normal:1.3|center:0()0()0()#ffffff:1| button-animation |ihewc-fade-up| title-animation |ihewc-fade-up|OxiAdmin-title-size |20|20|20| OxiAdmin-title-color |#ffffff|OxiAdmin-title-family |Open+Sans|600|OxiAdmin-title-style |normal:1.3|center:0()0()0()#ffffff:1|OxiAdmin-title-margin-top |2|2|2|OxiAdmin-title-margin-bottom |7|7|7|OxiAdmin-title-margin-left |2|2|2|OxiAdmin-title-margin-right |2|2|2| content-animation |ihewc-fade-up|OxiAdmin-content-size |16|16|16| OxiAdmin-content-color |#ffffff|OxiAdmin-content-family |Open+Sans|600|OxiAdmin-content-style |normal:1.3|center:0()0()0()#ffffff:1|OxiAdmin-content-margin-top |3|3|3|OxiAdmin-content-margin-bottom |3|3|3|OxiAdmin-content-margin-left |3|3|3|OxiAdmin-content-margin-right |3|3|3|OxiAdmin-title-underline-size |120|120|120|OxiAdmin-title-underline-height |0|0|0|OxiAdmin-title-underline |solid|#e300a3||OxiAdmin-underline-margin-top |0|0|0|OxiAdmin-underline-margin-bottom |3|3|3|OxiAdmin-underline-margin-left |0|0|0|OxiAdmin-underline-margin-right |0|0|0||||#|| ||#|||##OXISTYLE##OxiAdmin-file-first-icon||#||Image Hover Title||#||OxiAdmin-file-desc||#||Add Your Description Unless make it blank.||#||OxiAdmin-file-button-text||#||Buy Now||#||OxiAdmin-file-hover-link||#||#||#||OxiAdmin-file-image||#||OxiAddonsUrl.//wp-content/uploads/2019/05/6.jpg||#||||#|| ||#||##OXIDATA##',
    'Style 5 <span> 4 effects</span>OXIIMPORThover_effectsOXIIMPORTstyle-5OXIIMPORToxi-addons-preview-BG || ||image-alignments|justify-content: center;|OxiAdmin-Item |oxi-addons-lg-col-1|oxi-addons-md-col-1|oxi-addons-xs-col-1| OxiAddCB-button-link-opening ||OxiAdmin-padding-top |20|20|20|OxiAdmin-padding-bottom |20|20|20|OxiAdmin-padding-left |20|20|20|OxiAdmin-padding-right |20|20|20|OxiAdmin-margin-top |3|3|3|OxiAdmin-margin-bottom |3|3|3|OxiAdmin-margin-left |3|3|3|OxiAdmin-margin-right |3|3|3|OxiAdmin-animation||2:false:false:500:10:0.2|0//|OxiAdmin-box-shadow |rgba(224, 224, 224, 0.74)|0|0|3|1||OxiAdmin-hover-box-shadow |rgba(109, 3, 222, 0.49)|0|0|3|1|| OxiAdmin-width |250| OxiAdmin-height|250|OxiAdmin-I-bg|rgba(112, 3, 222, 1)|||OxiAdmin-border-radius-top |0|0|0|OxiAdmin-border-radius-bottom |0|0|0|OxiAdmin-border-radius-left |0|0|0|OxiAdmin-border-radius-right |0|0|0|OxiAdmin-hover-border-radius-top |0|0|0|OxiAdmin-hover-border-radius-bottom |0|0|0|OxiAdmin-hover-border-radius-left |0|0|0|OxiAdmin-hover-border-radius-right |0|0|0|OxiAdmin-button-size |14|14|14||||| OxiAdmin-button-color |#9100bd| OxiAdmin-button-bgcolor |rgba(255, 255, 255, 1)|OxiAdmin-button-border-top |0|0|0|OxiAdmin-button-border-bottom |0|0|0|OxiAdmin-button-border-left |0|0|0|OxiAdmin-button-border-right |0|0|0|OxiAdmin-button-border |solid|#ffffff||OxiAdmin-button-radius-top |50|50|50|OxiAdmin-button-radius-bottom |50|50|50|OxiAdmin-button-radius-left |50|50|50|OxiAdmin-button-radius-right |50|50|50|OxiAdmin-button-margin-top |3|3|3|OxiAdmin-button-margin-bottom |3|3|3|OxiAdmin-button-margin-left |3|3|3|OxiAdmin-button-margin-right |3|3|3| OxiAdmin-button-hover-color |#ffffff| OxiAdmin-button-hover-bgcolor |rgba(145, 0, 189, 0.81)|OxiAdmin-hover-button-border |solid|#ffffff||OxiAdmin-hover-button-radius-top |50|50|50|OxiAdmin-hover-button-radius-bottom |50|50|50|OxiAdmin-hover-button-radius-left |50|50|50|OxiAdmin-hover-button-radius-right |50|50|50|OxiAdmin-button-padding-top |8|8|8|OxiAdmin-button-padding-bottom |8|8|8|OxiAdmin-button-padding-left |12|12|12|OxiAdmin-button-padding-right |12|12|12|OxiAdmin-button-family |Open+Sans|600|OxiAdmin-button-style |normal:1.3|center:0()0()0()#ffffff:1| button-animation |ihewc-fade-up| title-animation |ihewc-fade-up|OxiAdmin-title-size |20|20|20| OxiAdmin-title-color |#ffffff|OxiAdmin-title-family |Open+Sans|600|OxiAdmin-title-style |normal:1.3|center:0()0()0()#ffffff:1|OxiAdmin-title-margin-top |2|2|2|OxiAdmin-title-margin-bottom |7|7|7|OxiAdmin-title-margin-left |2|2|2|OxiAdmin-title-margin-right |2|2|2| content-animation |ihewc-fade-up|OxiAdmin-content-size |16|16|16| OxiAdmin-content-color |#ffffff|OxiAdmin-content-family |Open+Sans|600|OxiAdmin-content-style |normal:1.3|center:0()0()0()#ffffff:1|OxiAdmin-content-margin-top |3|3|3|OxiAdmin-content-margin-bottom |3|3|3|OxiAdmin-content-margin-left |3|3|3|OxiAdmin-content-margin-right |3|3|3|OxiAdmin-title-underline-size |120|120|120|OxiAdmin-title-underline-height |0|0|0|OxiAdmin-title-underline |solid|#e300a3||OxiAdmin-underline-margin-top |0|0|0|OxiAdmin-underline-margin-bottom |3|3|3|OxiAdmin-underline-margin-left |0|0|0|OxiAdmin-underline-margin-right |0|0|0||||#|| ||#|||##OXISTYLE##OxiAdmin-file-first-icon||#||Image Hover Title||#||OxiAdmin-file-desc||#||Add Your Description Unless make it blank.||#||OxiAdmin-file-button-text||#||Buy Now||#||OxiAdmin-file-hover-link||#||#||#||OxiAdmin-file-image||#||OxiAddonsUrl.//wp-content/uploads/2019/05/6.jpg||#||||#|| ||#||##OXIDATA##',
);
if ($oxiimpport == 'import') {
    ?>
    <div class="wrap">
        <?php
        echo OxiAddonsAdmAdminMenu($oxitype, '', '', 'yes');
        echo '<div class="oxi-addons-wrapper">
                <div class="oxi-addons-row">
                    <div class="oxi-addons-view-more-demo" style=" padding-top: 35px; padding-bottom: 35px; ">
                        <div class="oxi-addons-view-more-demo-data" >
                            <div class="oxi-addons-view-more-demo-icon">
                                <i class="fas fa-bullhorn oxi-icons"></i>
                            </div>
                            <div class="oxi-addons-view-more-demo-text">
                                <div class="oxi-addons-view-more-demo-heading">
                                    More Layouts
                                </div>
                                <div class="oxi-addons-view-more-demo-content">
                                    Thank you for using Shortcode Addons. As limitation of viewing Layouts or Design we added some layouts. Kindly check more  <a target="_blank" href="https://www.oxilab.org/shortcode-addons-features/' . str_replace('_', '-', $oxitype) . '" >' . oxi_addons_shortcode_name_converter($oxitype) . '</a> design from Oxilab.org. Copy <strong>export</strong> code and <strong>import</strong> it, get your preferable layouts.
                                </div>
                            </div>
                            <div class="oxi-addons-view-more-demo-button">
                                <a target="_blank" class="oxi-addons-more-layouts" href="https://www.oxilab.org/shortcode-addons-features/' . str_replace('_', '-', $oxitype) . '" >View layouts</a>
                            </div>
                        </div>
                    </div>
                </div>
           </div>';
        ?>

        <div class="oxi-addons-wrapper">
            <div class="oxi-addons-row">
                <?php
                foreach ($file as $value) {
                    $expludedata = explode('OXIIMPORT', $value);
                    $datatrue = '';
                    foreach ($importstyle as $vals) {
                        if ($vals['name'] == $expludedata[2]) {
                            $datatrue = 'true';
                        }
                    }
                    if ($datatrue != 'true') {
                        $number = rand();
                        echo '<div class="oxi-addons-col-6"><div class="oxi-addons-style-preview"><div class="oxi-addons-style-preview-top oxi-addons-center">';
                        echo OxiDataAdminShortcode($oxitype, $value);
                        echo '</div>
                         <div class="oxi-addons-style-preview-bottom">
                            <div class="oxi-addons-style-preview-bottom-left">';
                        echo OxiDataAdminShortcodeName($value);
                        echo '       </div>';
                        echo '  <div class="oxi-addons-style-preview-bottom-right">
                                    <form method="post" style=" display: inline-block; ">
                                        ' . wp_nonce_field("oxi-addons-$expludedata[1]-style-active-nonce") . '
                                        <input type="hidden" name="oxiactivestyle" value="' . $expludedata[2] . '">
                                        <button class="btn btn-success" title="Active"  type="submit" value="Active" name="addonsstyleactive">Import Style</button>  
                                    </form> 
                                </div>';
                        echo '            </div>
                   </div>
                </div>';
                    }
                }
                ?>
            </div>
        </div>
    </div>

    <?php
} else {
    $data = $wpdb->get_results("SELECT * FROM $table_name WHERE type = '$oxitype' ORDER BY id DESC", ARRAY_A);
    ?>
    <div class="wrap">
        <?php echo OxiAddonsAdmAdminMenu($oxitype, '', '', 'yes'); ?>
        <?php echo OxiAddonsAdmAdminShortcodeTable($data, $oxitype); ?>
        <div class="oxi-addons-wrapper">
            <div class="oxi-addons-row">
                <?php
                foreach ($file as $value) {
                    $expludedata = explode('OXIIMPORT', $value);
                    $datatrue = '';
                    foreach ($importstyle as $vals) {
                        if ($vals['name'] == $expludedata[2]) {
                            $datatrue = 'true';
                        }
                    }
                    if ($datatrue == 'true') {
                        $number = rand();
                        echo '<div class="oxi-addons-col-6" id="' . $expludedata[2] . '"><div class="oxi-addons-style-preview"><div class="oxi-addons-style-preview-top oxi-addons-center">';
                        echo OxiDataAdminShortcode($oxitype, $value);
                        echo '</div>
                         <div class="oxi-addons-style-preview-bottom">
                            <div class="oxi-addons-style-preview-bottom-left">';
                        echo OxiDataAdminShortcodeName($value);
                        echo '       </div>';
                        echo OxiDataAdminShortcodeControl($number, $value, $freeimport);
                        echo '            </div>
                   </div>
                </div>';
                    }
                }
                ?>
                <div class="oxi-addons-col-1 oxi-import">
                    <div class="oxi-addons-style-preview">
                        <div class="oxilab-admin-style-preview-top">
                            <a href="<?php echo admin_url("admin.php?page=oxi-addons&oxitype=$oxitype&oxiimpport=import"); ?>">
                                <div class="oxilab-admin-add-new-item">
                                    <span>
                                        <i class="fas fa-plus-circle oxi-icons"></i>  
                                        Add More Templates
                                    </span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
    echo OxiDataAdminShortcodeModal($oxitype);
}