<?php
if (!defined('ABSPATH')) {
    exit;
}

$oxitype = sanitize_text_field($_GET['oxitype']);
$oxiimpport = '';
if(!empty($_GET['oxiimpport'])){
    $oxiimpport = sanitize_text_field($_GET['oxiimpport']);
}

oxi_addons_user_capabilities();
OxiDataAdminImport($oxitype);
global $wpdb;
$table_name = $wpdb->prefix . 'oxi_div_style';
$table_import = $wpdb->prefix . 'oxi_div_import';
$importstyle = $wpdb->get_results("SELECT * FROM $table_import WHERE type = '$oxitype' ORDER BY id DESC", ARRAY_A);
$freeimport = array('style-1', 'style-2', 'style-3', 'style-4');
if (count($importstyle) < 1) {
    foreach ($freeimport as $value) {
        $wpdb->query($wpdb->prepare("INSERT INTO {$table_import} (type, name) VALUES (%s, %s )", array($oxitype, $value)));
    }
    $js = 'location.reload();';
    wp_add_inline_script('oxi-addons-vendor', $js);
}
$file = array(
                'Banner style 01OXIIMPORTdisplay_postOXIIMPORTstyle-1OXIIMPORToxi-addons-preview-BG |rgba(255, 255, 255, 0)|OxiAddonsBanner-G-P-top |100|70|50|OxiAddonsBanner-G-P-bottom |100|70|50|OxiAddonsBanner-G-P-left |35|25|25|OxiAddonsBanner-G-P-right |35|25|25| OxiAddonsBanner-Animation|pulse|.5|.5//||OxiAddonsBanner-H-FS |80|55|40|OxiAddonsBanner-H-F-family |caros-bold|bold|OxiAddonsBanner-H-F-style |normal:1|left:0()0()0()#ffffff| OxiAddonsBanner-H-C |#ffffff|OxiAddonsBanner-H-P-top |5|5|5|OxiAddonsBanner-H-P-bottom |20|20|20|OxiAddonsBanner-H-P-left |5|5|5|OxiAddonsBanner-H-P-right |5|5|5|OxiAddonsBanner-SD-FS |16|16|16|OxiAddonsBanner-SD-F-family |caros-bold|normal|OxiAddonsBanner-SD-F-style |normal:1.3|left:0()0()0()#ffffff| OxiAddonsBanner-SD-C |#f0f0f0|OxiAddonsBanner-SD-P-top |20|10|10|OxiAddonsBanner-SD-P-bottom |20|10|10|OxiAddonsBanner-SD-P-left |5|5|5|OxiAddonsBanner-SD-P-right |0|10|10| OxiAddonsBanner-B-Left-Tab ||OxiAddonsBanner-B-Left-FS |16|15|14|OxiAddonsBanner-B-Left-F-family |caros-bold|500|OxiAddonsBanner-B-Left-F-style |normal|| OxiAddonsBanner-B-Left-TC |#ffffff| OxiAddonsBanner-B-Left-BG |rgba(17,106,177,1.00)|OxiAddonsBanner-B-Left-BR-top |50|50|50|OxiAddonsBanner-B-Left-BR-bottom |50|50|50|OxiAddonsBanner-B-Left-BR-left |50|50|50|OxiAddonsBanner-B-Left-BR-right |50|50|50|OxiAddonsBanner-B-Left-BS |rgba(56, 55, 55, 0.4)|0|8|15|0| OxiAddonsBanner-B-Left-HTC |#116ab1| OxiAddonsBanner-B-Left-HBG |rgba(255, 255, 255, 1)|OxiAddonsBanner-B-Left-B |0|solid|| OxiAddonsBanner-B-Left-BC |#ffffff|OxiAddonsBanner-B-Left-P-top |10|10|10|OxiAddonsBanner-B-Left-P-bottom |10|10|10|OxiAddonsBanner-B-Left-P-left |25|25|25|OxiAddonsBanner-B-Left-P-right |25|25|25|OxiAddonsBanner-B-Left-M-top |0|0|0|OxiAddonsBanner-B-Left-M-bottom |0|0|0|OxiAddonsBanner-B-Left-M-left |5|5|5|OxiAddonsBanner-B-Left-M-right |0|0|0| OxiAddonsBanner-B-Left-Tab ||OxiAddonsBanner-B-Right-FS |16|16|16|OxiAddonsBanner-B-Right-F-family |inherit|normal|OxiAddonsBanner-B-Right-F-style |normal|| OxiAddonsBanner-B-Right-TC |#ffffff| OxiAddonsBanner-B-Right-I-TC |#ffffff|OxiAddonsBanner-B-Right-I-FS |26|26|26||| OxiAddonsBanner-B-Right-HTC |#116ab1| OxiAddonsBanner-B-Right-HIC |#116ab1|OxiAddonsBanner-B-Right-P-top |1|1|1|OxiAddonsBanner-B-Right-P-bottom |1|1|1|OxiAddonsBanner-B-Right-P-left |1|1|1|OxiAddonsBanner-B-Right-P-right |1|1|1|OxiAddonsBanner-B-Right-M-top |0|0|0|OxiAddonsBanner-B-Right-M-bottom |0|0|0|OxiAddonsBanner-B-Right-M-left |5|5|5|OxiAddonsBanner-B-Right-M-right |0|0|0|||OxiAddonsBanner-B-Left-HBS |rgba(255, 255, 255, 0.25)|0|8|15|0||||||| OxiAddonsBanner-G-BG-PS |left| OxiAddonsBanner-B-Left-Animation|fadeInLeft|0.5|0.4//|| OxiAddonsBanner-B-Left-HBC |#ffffff| OxiAddonsBanner-B-Right-Animation|bounceInLeft|0.5|0.5//|| OxiAddonsBanner-G-BPS |left|OxiAddonsBanner-G-BG|rgba(0,0,0,0.44)|https://www.oxilab.org/wp-content/uploads/2019/04/180168-nature-landscape-animals-trees-sunset-silhouette-birds-photo_manipulation-deer-horizon-reflection-orange.jpg||||#|| OxiAddonsBanner-G-F-IMG ||#||https://www.oxilab.org/wp-content/uploads/2019/04/rog_zephyrus_2.png||#|| OxiAddonsBanner-H-TB ||#||Global SmartPhone Sales||#|| OxiAddonsBanner-SD-TA ||#||Share your challenge with our team and we l work with you to deliver a revolutionary digital product.||#|| OxiAddonsBanner-B-Left-BT ||#||GET STARTED||#|| OxiAddonsBanner-B-Left-BL ||#||#||#|| OxiAddonsBanner-B-Left-I-TB ||#||fa fa-angle-right||#|| OxiAddonsBanner-B-Right-BT ||#||See live demo||#|| OxiAddonsBanner-B-Right-BL ||#||#||#|| OxiAddonsBanner-B-Right-I-TB ||#||far fa-play-circle||#|| ||#||',
            );
if ($oxiimpport == 'import') {
    ?>
    <div class="wrap">
        <?php
        echo OxiAddonsAdmAdminMenu($oxitype, '', '', 'yes');
        echo '<div class="oxi-addons-wrapper">
                <div class="oxi-addons-row">
                    <div class="oxi-addons-view-more-demo" style=" padding-top: 35px; padding-bottom: 35px; ">
                        <div class="oxi-addons-view-more-demo-data" >
                            <div class="oxi-addons-view-more-demo-icon">
                                <i class="fas fa-bullhorn oxi-icons"></i>
                            </div>
                            <div class="oxi-addons-view-more-demo-text">
                                <div class="oxi-addons-view-more-demo-heading">
                                    More Layouts
                                </div>
                                <div class="oxi-addons-view-more-demo-content">
                                    Thank you for using Shortcode Addons. As limitation of viewing Layouts or Design we added some layouts. Kindly check more  <a target="_blank" href="https://www.oxilab.org/shortcode-addons-features/' . str_replace('_', '-', $oxitype) . '" >' . oxi_addons_shortcode_name_converter($oxitype) . '</a> design from Oxilab.org. Copy <strong>export</strong> code and <strong>import</strong> it, get your preferable layouts.
                                </div>
                            </div>
                            <div class="oxi-addons-view-more-demo-button">
                                <a target="_blank" class="oxi-addons-more-layouts" href="https://www.oxilab.org/shortcode-addons-features/' . str_replace('_', '-', $oxitype) . '" >View layouts</a>
                            </div>
                        </div>
                    </div>
                </div>
           </div>';
        ?>

        <div class="oxi-addons-wrapper">
            <div class="oxi-addons-row">
                <?php
                foreach ($file as $value) {
                    $expludedata = explode('OXIIMPORT', $value);
                    $datatrue = '';
                    foreach ($importstyle as $vals) {
                        if ($vals['name'] == $expludedata[2]) {
                            $datatrue = 'true';
                        }
                    }
                    if ($datatrue != 'true') {
                        $number = rand();
                        echo '<div class="oxi-addons-col-1"><div class="oxi-addons-style-preview"><div class="oxi-addons-style-preview-top oxi-addons-center">';
                        echo OxiDataAdminShortcode($oxitype, $value);
                        echo '</div>
                         <div class="oxi-addons-style-preview-bottom">
                            <div class="oxi-addons-style-preview-bottom-left">';
                        echo OxiDataAdminShortcodeName($value);
                        echo '       </div>';
                        echo '  <div class="oxi-addons-style-preview-bottom-right">
                                    <form method="post" style=" display: inline-block; ">
                                        ' . wp_nonce_field("oxi-addons-$expludedata[1]-style-active-nonce") . '
                                        <input type="hidden" name="oxiactivestyle" value="' . $expludedata[2] . '">
                                        <button class="btn btn-success" title="Active"  type="submit" value="Active" name="addonsstyleactive">Import Style</button>  
                                    </form> 
                                </div>';
                        echo '            </div>
                   </div>
                </div>';
                    }
                }
                ?>
            </div>
        </div>
    </div>

    <?php
} else {
    $data = $wpdb->get_results("SELECT * FROM $table_name WHERE type = '$oxitype' ORDER BY id DESC", ARRAY_A);
    ?>
    <div class="wrap">
        <?php echo OxiAddonsAdmAdminMenu($oxitype, '', '', 'yes'); ?>
        <?php echo OxiAddonsAdmAdminShortcodeTable($data, $oxitype); ?>
        <div class="oxi-addons-wrapper">
            <div class="oxi-addons-row">
                <?php
                foreach ($file as $value) {
                    $expludedata = explode('OXIIMPORT', $value);
                    $datatrue = '';
                    foreach ($importstyle as $vals) {
                        if ($vals['name'] == $expludedata[2]) {
                            $datatrue = 'true';
                        }
                    }
                    if ($datatrue == 'true') {
                        $number = rand();
                        echo '<div class="oxi-addons-col-1" id="'.$expludedata[2].'"><div class="oxi-addons-style-preview"><div class="oxi-addons-style-preview-top oxi-addons-center">';
                        echo OxiDataAdminShortcode($oxitype, $value);
                        echo '</div>
                         <div class="oxi-addons-style-preview-bottom">
                            <div class="oxi-addons-style-preview-bottom-left">';
                        echo OxiDataAdminShortcodeName($value);
                        echo '       </div>';
                        echo OxiDataAdminShortcodeControl($number, $value, $freeimport);
                        echo '            </div>
                   </div>
                </div>';
                    }
                }
                ?>
                <div class="oxi-addons-col-1 oxi-import">
                    <div class="oxi-addons-style-preview">
                        <div class="oxilab-admin-style-preview-top">
                            <a href="<?php echo admin_url("admin.php?page=oxi-addons&oxitype=$oxitype&oxiimpport=import"); ?>">
                                <div class="oxilab-admin-add-new-item">
                                    <span>
                                        <i class="fas fa-plus-circle oxi-icons"></i>  
                                        Add More Templates
                                    </span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
    echo OxiDataAdminShortcodeModal($oxitype);
}

