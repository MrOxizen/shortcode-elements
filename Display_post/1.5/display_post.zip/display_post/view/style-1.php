<?php

if (!defined('ABSPATH')) {
    exit;
}

function oxi_display_post_style_1_shortcode($style = false, $listdata = false, $user = 'user')
{
    $oxiid = $style['id'];
    $stylefiles = explode('||#||', $style['css']);
    $styledata = explode('|', $stylefiles[0]);
    $css = '';
    $post_args = [
        'post_type' => $stylefiles[1],
        'posts_per_page' => $stylefiles[11],
        'orderby' => $stylefiles[15],
        'order' => $stylefiles[17],
        'offset' => $stylefiles[13],
        'ignore_sticky_posts' => 1,
        'post_status' => 'publish',
        'tax_query' => []
    ];
    if ($stylefiles[3] != '') {
        $post_args['author__in'] = explode('{|}{|}', $stylefiles[3]);
    }
    if ($stylefiles[5] != '') {
        $post_args['tax_query'][] = array(
            'taxonomy' => $stylefiles[1] == 'post' ? 'category' : $stylefiles[1] . '_category',
            'field' => 'term_id',
            'terms' => explode('{|}{|}', $stylefiles[5])
        );
    }
    if ($stylefiles[7] != '') {
        $post_args['tax_query'][] = array(
            'taxonomy' => $stylefiles[1] . '_tag',
            'field' => 'term_id',
            'terms' => explode('{|}{|}', $stylefiles[7])
        );
    }
    if ($stylefiles[9] != '') {
        $post_args['post__not_in'] = explode('{|}{|}', $stylefiles[9]);
    }
    if ($stylefiles[19] != '') {
        $post_args['post__in'] = explode('{|}{|}', $stylefiles[19]);
    }
    echo '<div class="oxi-addons-container"><div class="oxi-addons-row">';

    $query = new \WP_Query($post_args);
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $img = $title = $content_excerpt = $image_url = '';
            if ($stylefiles[21] == 'thumbnail') {
                $image_url = wp_get_attachment_image_src(get_post_thumbnail_id(), 'thumbnail');
            } elseif ($stylefiles[21] == 'medium') {
                $image_url = wp_get_attachment_image_src(get_post_thumbnail_id(), 'medium');
            } elseif ($stylefiles[21] == 'medium_large') {
                $image_url = wp_get_attachment_image_src(get_post_thumbnail_id(), 'medium_large');
            } elseif ($stylefiles[21] == 'large') {
                $image_url = wp_get_attachment_image_src(get_post_thumbnail_id(), 'medium_large');
            } elseif ($stylefiles[21] == 'post-thumbnail') {
                $image_url = wp_get_attachment_image_src(get_post_thumbnail_id(), 'post-thumbnail');
            } elseif ($stylefiles[21] == 'custom_size') {
                $image_url =   wp_get_attachment_image_src(get_post_thumbnail_id(), array($stylefiles[23], $stylefiles[25]));
            }
            if ($styledata[7] == 'show') {
                if ($image_url[0] != '') {
                    $img = '
                            <a class="oxi-addons__post-link" href="' . get_permalink($query->post->ID) . '"  target="' . $styledata[207] . '">
                                <div class="oxi-addons__main-img">
                                         
                                </div>
                            </a>
                        ';
                }
            }
            if ($styledata[11] == 'show') {
                $excerpt = str_word_count(strip_tags(get_the_excerpt()));
                if ($excerpt == 0) {
                    $posts = explode(' ', get_the_content(), $styledata[13]);
                } else {
                    $posts = explode(' ', get_the_excerpt(), $styledata[13]);
                }
                if (count($posts) >= $styledata[13]) {
                    array_pop($posts);
                    $posts = implode(" ", $posts) . '...';
                } else {
                    $posts = implode(" ", $posts);
                }
                $posts = preg_replace('/\[.+\]/', '', $posts);

                $content_excerpt = '  
                 <p class="oxi-addons__details">
                     ' . $posts . '
                 </p> 
            ';
            }
            if ($styledata[9] == 'show') {
                $title = '
                 <h2 class="oxi-addons__title">
                    <a class="oxi-link" title=" ' . get_the_title($query->post->ID) . '" href="' . get_permalink($query->post->ID) . '"  target="' . $styledata[207] . '"> ' . get_the_title($query->post->ID) . '</a>  
                </h2> 
            ';
            }
            $avater = $meta = $align = $header_footer =  '';
            $avater = get_avatar(get_the_author_meta('ID'));
            if ($styledata[15] == 'show') {
                $meta = '
                 <div class="oxi-addons__meta-info">
                    <div class="oxi-addons__meta-left"> 
                            '. $avater .'
                    </div>
                    <div class="oxi-addons__meta-right">
                        <div class="oxi-addons__meta-name">
                            <a class="oxi-name" href="'.esc_url(get_author_posts_url(get_the_author_meta('ID'))).'" title="Post By '. get_the_author_meta('display_name').'" rel="'. get_the_author_meta('display_name').'">'. get_the_author_meta('display_name').'</a>
                        </div>
                        <div class="oxi-addons__meta-date" >
                            <time class="oxi-time" datetime="'.   get_the_date('M d, Y') .'" >'.   get_the_date('M d, Y') .'</time>
                        </div>
                    </div>
                </div>
            ';
            }
            if ($styledata[141] == 'left') {
                $align = 'justify-content: flex-start;';
            } elseif ($styledata[141] == 'center') {
                $align = 'justify-content: center;';
            } else {
                $align = 'justify-content: flex-end;';
            }
            if ($styledata[17] == 'footer') {
                $header_footer = '
                    ' . $title . '
                    ' . OxiAddonsTextConvert($content_excerpt) . '
                    '.$meta.'
                ';
            } else {
                $header_footer = '
                     '.$meta.'
                    ' . $title . '
                    ' . OxiAddonsTextConvert($content_excerpt) . ' 
                ';
            }

            echo '
                <div class="oxi-addons-parent ' . OxiAddonsItemRows($styledata, 3) . ' ">
                    <div class="oxi-addons__main-wrapper-' . get_the_ID() . '">
                        <div class="oxi-addons__wrapper" ' . OxiAddonsAnimation($styledata, 81) . '> 
                        ' . $img . '
                            <div class="oxi-addons__article">
                                '. $header_footer .'
                            </div>
                    </div>
                </div>
            </div>
            ';
            $css .= '
            .oxi-addons__main-wrapper-' . get_the_ID() . '{
                display: flex;
                padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 59) . ';  
            }
            .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__wrapper{
                width: 100%; 
                display: flex;
                flex-direction: column;
                background: ' . $styledata[19] . ';
                border:  ' . $styledata[21] . 'px ' . $styledata[22] . ';  
                border-color: ' . $styledata[25] . '; 
                border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 27) . ';
                ' . OxiAddonsBoxShadowSanitize($styledata, 75) . ';
                 overflow: hidden;
            } 
            .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__post-link:hover{
               cursor: pointer;
            }
            .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__main-img{
                display: flex;
                width: 100%;
                background-image: url('.$image_url[0].');
                background-position: center center;
                background-repeat: no-repeat;
                background-size: cover;
            }
         
            .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__main-img::after{ 
                content: "";
                display: block;
                padding-bottom:  ' . $styledata[203] . '%;
            }
            .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__article{ 
               width: 100%;
               display: flex;
               flex-direction: column; 
                padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 43) . ';

            }
            .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__title{  
                 display: flex;
                 width: 100%;
            }
            .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-link{  
                font-size: ' . $styledata[85] . 'px;
                color: ' . $styledata[89] . ';
                ' . OxiAddonsFontSettings($styledata, 91) . ';
                padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 97) . '; 
            }
            .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-link:hover{   
                color: ' . $styledata[205] . '; 
            }
            .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__details{  
                font-size: ' . $styledata[113] . 'px;
                color: ' . $styledata[117] . ';
                ' . OxiAddonsFontSettings($styledata, 119) . ';
                padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 125) . '; 
            }
            .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-info{  
                display: flex;
                '.$align.'
                padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 149) . '; 
            }
            .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-left{  
               display: flex;
            }
            .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-left > img,
            .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-left > .oxi-addons__avater{  
                  border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 187) . ';
                  width: '.$styledata[179].'px;
                  max-width: 100%;
                  height: '.$styledata[183].'px;
            } 
             .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-right{  
               display: flex;
               flex-direction: column;
               justify-content: center;
            } 
             .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-name{  
                 padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 209) . '; 
            }
             .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-name > .oxi-name{  
                 font-size: ' . $styledata[165] . 'px;
                color: ' . $styledata[169] . ';
                ' . OxiAddonsFontSettings($styledata, 143) . ';  
            }
             .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-name > .oxi-name:hover{   
                color: ' . $styledata[171] . '; 
            }
             .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-date{  
                   padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 225) . '; 
            }
            
             .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-date > .oxi-time{  
                 font-size: ' . $styledata[173] . 'px;
                color: ' . $styledata[177] . ';
                ' . OxiAddonsFontSettings($styledata, 143) . '; 
            }
            
            @media only screen and (min-width : 669px) and (max-width : 993px){
                 .oxi-addons__main-wrapper-' . get_the_ID() . '{ 
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 60) . ';  
                }
                .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__wrapper{  
                    border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 28) . '; 
                }   
                .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__article{  
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 44) . '; 
                } 
                .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-link{  
                    font-size: ' . $styledata[86] . 'px; 
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 98) . '; 
                } 
                .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__details{  
                    font-size: ' . $styledata[114] . 'px; 
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 126) . '; 
                }
                .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-info{   
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 150) . '; 
                } 
                .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-left > img,
                .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-left > .oxi-addons__avater{  
                    border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 188) . ';
                    width: '.$styledata[180].'px; 
                    height: '.$styledata[184].'px;
                }   
                .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-name{ 
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 210) . '; 
                } 
                .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-name > .oxi-name{  
                    font-size: ' . $styledata[166] . 'px;  
                } 
                .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-date{   
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 226) . ';  
                }
                .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-date > .oxi-time{  
                    font-size: ' . $styledata[174] . 'px;  
                }
            }
            @media only screen and (max-width : 668px){
                .oxi-addons__main-wrapper-' . get_the_ID() . '{ 
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 61) . ';  
                }
                .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__wrapper{  
                    border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 29) . '; 
                }   
                .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__article{  
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 45) . '; 
                } 
                .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-link{  
                    font-size: ' . $styledata[87] . 'px; 
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 99) . '; 
                } 
                .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__details{  
                    font-size: ' . $styledata[115] . 'px; 
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 127) . '; 
                }
                .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-info{   
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 151) . '; 
                } 
                .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-left > img,
                .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-left > .oxi-addons__avater{  
                    border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 189) . ';
                    width: '.$styledata[181].'px; 
                    height: '.$styledata[185].'px;
                }   
                .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-name{   
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 211) . '; 
                } 
                .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-name > .oxi-name{  
                    font-size: ' . $styledata[167] . 'px;  
                } 
                .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-date{   
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 227) . ';  
                }
                .oxi-addons__main-wrapper-' . get_the_ID() . ' .oxi-addons__meta-date > .oxi-time{  
                    font-size: ' . $styledata[175] . 'px;  
                }
            }
        ';
            echo OxiAddonsInlineCSSData($css);
            $js = 'setTimeout(function () {oxiequalHeight(jQuery(".oxi-addons__main-wrapper-' . get_the_ID() . '"));}, 500);';
            echo OxiAddonsInlineCSSData($js, 'js', 'oxi-addons-animation');
        }
        wp_reset_postdata();
    }
    echo '</div>
    </div>';
}

?>

<script>
   setTimeout(function(){
     var selector = document.querySelector('.oxi-addons__meta-left');
     selector.children[0].classList.add('oxi-addons__avater');
   },100)
</script>

