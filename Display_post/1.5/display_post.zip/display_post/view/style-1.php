<?php

if (!defined('ABSPATH')) {
    exit;
}

function oxi_display_post_style_1_shortcode($style = false, $listdata = false, $user = 'user')
{
    $oxiid = $style['id'];
    $stylefiles = explode('||#||', $style['css']);
    $styledata = explode('|', $stylefiles[0]);
    $css = '';
    $post_args = [
        'post_type' => $stylefiles[1],
        'posts_per_page' => $stylefiles[11],
        'orderby' => $stylefiles[15],
        'order' => $stylefiles[17],
        'offset' => $stylefiles[13],
        'ignore_sticky_posts' => 1,
        'post_status' => 'publish',
        'tax_query' => []
    ];
    if ($stylefiles[3] != '') {
        $post_args['author__in'] = explode('{|}{|}', $stylefiles[3]);
    }
    if ($stylefiles[5] != '') {
        $post_args['tax_query'][] = array(
            'taxonomy' => $stylefiles[1] == 'post'? 'category': $stylefiles[1] . '_category',
            'field' => 'term_id',
            'terms' => explode('{|}{|}', $stylefiles[5])
        );
    }
    if ($stylefiles[7] != '') {
        $post_args['tax_query'][] = array(
            'taxonomy' => $stylefiles[1] . '_tag',
            'field' => 'term_id',
            'terms' => explode('{|}{|}', $stylefiles[7])
        );
    }
    if ($stylefiles[9] != '') {
        $post_args['post__not_in'] = explode('{|}{|}', $stylefiles[9]);
    }
    if ($stylefiles[19] != '') {
        $post_args['post__in'] = explode('{|}{|}', $stylefiles[19]);
    }
    echo '<div class="oxi-addons-container"><div class="oxi-addons-row">';

    $query = new \WP_Query($post_args);
    if ($query->have_posts()) {
        // The 2nd Loop
        while ($query->have_posts()) {
            $query->the_post();
            function excerpt($limit)
            {
                $excerpt = str_word_count(strip_tags(get_the_excerpt()));

                if ($excerpt == 0) {
                    $posts = explode(' ', get_the_content(), $limit);
                } else {
                    $posts = explode(' ', get_the_excerpt(), $limit);
                }
                if (count($posts) >= $limit) {
                    array_pop($posts);
                    $posts = implode(" ", $posts) . '...';
                } else {
                    $posts = implode(" ", $posts);
                }
                $posts = preg_replace('/\[.+\]/', '', $posts);
                return $posts;
            }
            $img = $title = $content_excerpt = $image_url = '';

           


            if ($stylefiles[21] == 'thumbnail') {
                if (has_post_thumbnail('thumbnail')) {
                    $image_url = wp_get_attachment_image_src(get_post_thumbnail_id(), 'thumbnail');
                }
            } elseif ($stylefiles[21] == 'medium') {
                $image_url = the_post_thumbnail('medium');
            } elseif ($stylefiles[21] == 'medium_large') {
                $image_url = the_post_thumbnail('medium_large');
            } elseif ($stylefiles[21] == 'large') {
                $image_url = the_post_thumbnail('large');
            } elseif ($stylefiles[21] == 'post_thumbnail') {
                $image_url = the_post_thumbnail(array(1200, 9999));
            } elseif ($stylefiles[21] == 'full') {
                $image_url = the_post_thumbnail('full');
            }
            if ($styledata[7] == 'show') {
                if ($image_url != '') {
                    $img = '  
                            <a class="oxi-addons__post-link" href="'. get_permalink($query->post->ID) .'">
                                <div class="oxi-addons__main-img">
                                        <img class="oxi-addons__img" src="'. $image_url .'" alt="' . get_the_title($query->post->ID) . '"/> 
                                </div>
                            </a>
                        ';
                }
            }
            if ($styledata[11] == 'show') {
                $content_excerpt = '
                 <p class="oxi-addons__details">
                     '. excerpt($styledata[13]) .'
                 </p> 
            ';
            }
            if ($styledata[9] == 'show') {
                $title = '
                 <h2 class="oxi-addons__title">
                    <a class="oxi-link" href="'.get_permalink($query->post->ID).'"> ' . get_the_title($query->post->ID) . '</a>  
                </h2> 
            ';
            }
            echo '
                <div class="' . OxiAddonsItemRows($styledata, 3) . ' ">
                    <div class="oxi-addons__main-wrapper-'. get_the_ID() .'">
                        <div class="oxi-addons__wrapper" ' . OxiAddonsAnimation($styledata, 81) . '> 
                        '. $img .'
                            <div class="oxi-addons__article">
                                '. $title .'
                                 ' . OxiAddonsTextConvert($content_excerpt) . '
                                <div class="oxi-addons__meta-info"></div>
                            </div>
                    </div>
                </div>
            </div>
            ';
            $css .= '
            .oxi-addons__main-wrapper-'. get_the_ID() .'{
                display: flex;
                padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 59) . '; 
               
            }
            .oxi-addons__main-wrapper-'. get_the_ID() .' .oxi-addons__wrapper{
                width: 100%; 
                display: flex;
                flex-direction: column;
                background: ' . $styledata[19] . ';
                border:  ' . $styledata[21] . 'px ' . $styledata[22] . ';  
                border-color: ' . $styledata[25] . '; 
                border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 27) . ';
                padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 43) . '; 
                ' . OxiAddonsBoxShadowSanitize($styledata, 75) . ';
                 overflow: hidden;
            }
            .oxi-addons__main-wrapper-'. get_the_ID() .' .oxi-addons__img{
               width: 100%;
               height: auto;
               object-fit: cover;
            }
            .oxi-addons__main-wrapper-'. get_the_ID() .' .oxi-addons__post-link:hover{
               cursor: pointer;
            }
            .oxi-addons__main-wrapper-'. get_the_ID() .' .oxi-addons__main-img{
                display: flex;
                width: 100%;
            }
         
            .oxi-addons__main-wrapper-'. get_the_ID() .' .oxi-addons__main-img::after{ 
                content: "";
                display: block;
                padding-bottom:  ' . $styledata[203] . '%;
            }
            .oxi-addons__main-wrapper-'. get_the_ID() .' .oxi-addons__article{ 
               width: 100%;
               display: flex;
               flex-direction: column;
            }
            .oxi-addons__main-wrapper-'. get_the_ID() .' .oxi-addons__title{  
                 display: flex;
                 width: 100%;
            }
            .oxi-addons__main-wrapper-'. get_the_ID() .' .oxi-link{  
                font-size: ' . $styledata[85] . 'px;
                color: ' . $styledata[89] . ';
                ' . OxiAddonsFontSettings($styledata, 91) . ';
                padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 97) . '; 
            }
            .oxi-addons__main-wrapper-'. get_the_ID() .' .oxi-link:hover{   
                color: ' . $styledata[205] . '; 
            }
            .oxi-addons__main-wrapper-'. get_the_ID() .' .oxi-addons__details{  
                font-size: ' . $styledata[113] . 'px;
                color: ' . $styledata[117] . ';
                ' . OxiAddonsFontSettings($styledata, 119) . ';
                padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 125) . '; 
            }
            
            @media only screen and (min-width : 669px) and (max-width : 993px){
            
            }
            @media only screen and (max-width : 668px){
            
            }
        ';
            echo OxiAddonsInlineCSSData($css);
        }
        wp_reset_postdata();
    }
    echo '</div>
    </div>';
}
