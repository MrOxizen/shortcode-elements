<?php
if (!defined('ABSPATH')) {
    exit;
}

$oxitype = sanitize_text_field($_GET['oxitype']);
$oxiimpport = '';
if (!empty($_GET['oxiimpport'])) {
    $oxiimpport = sanitize_text_field($_GET['oxiimpport']);
}

oxi_addons_user_capabilities();
OxiDataAdminImport($oxitype);
global $wpdb;
$table_name = $wpdb->prefix . 'oxi_div_style';
$table_import = $wpdb->prefix . 'oxi_div_import';
$importstyle = $wpdb->get_results("SELECT * FROM $table_import WHERE type = '$oxitype' ORDER BY id DESC", ARRAY_A);
$freeimport = array('style-1');
if (count($importstyle) < 1) {
    foreach ($freeimport as $value) {
        $wpdb->query($wpdb->prepare("INSERT INTO {$table_import} (type, name) VALUES (%s, %s )", array($oxitype, $value)));
    }
    $js = 'location.reload();';
    wp_add_inline_script('oxi-addons-vendor', $js);
}
$file = array(
                'OXIIMPORTdisplay_postOXIIMPORTstyle-1OXIIMPORToxi-addons-preview-BG |rgba(255, 255, 255, 1)|OxiAddonsDP-rows |oxi-addons-lg-col-3|oxi-addons-md-col-1|oxi-addons-xs-col-1| OxiAddonsDP-show-image |show| OxiAddonsDP-show-title |show| OxiAddonsDP-show-excerpt |show| OxiAddonsDP-excerpt-word |20| OxiAddonsDP-show-meta |show| OxiAddonsDP-meta-position |footer| OxiAddonsDP-Post-S-BG |rgba(255, 255, 255, 1)|OxiAddonsDP-Post-S-B |1|solid|| OxiAddonsDP-Post-S-BC |#e3e3e3|OxiAddonsDP-Post-S-BR-top |0|0|0|OxiAddonsDP-Post-S-BR-bottom |0|0|0|OxiAddonsDP-Post-S-BR-left |0|0|0|OxiAddonsDP-Post-S-BR-right |0|0|0|OxiAddonsDP-Post-S-P-top |10|10|10|OxiAddonsDP-Post-S-P-bottom |10|10|10|OxiAddonsDP-Post-S-P-left |10|10|10|OxiAddonsDP-Post-S-P-right |10|10|10|OxiAddonsDP-Post-S-M-top |5|5|5|OxiAddonsDP-Post-S-M-bottom |5|5|5|OxiAddonsDP-Post-S-M-left |5|5|5|OxiAddonsDP-Post-S-M-right |5|5|5|OxiAddonsDP-box-shadow |rgba(232, 232, 232, 1):|0|1|2|1|OxiAddonsDP-animation||0:false:false:500:10:0.2|0//|OxiAddonsDP-title-FS|22|22|22| OxiAddonsDP-title-C |#2ba5ba|OxiAddonsDP-title-F-family |Nunito|100|OxiAddonsDP-title-F-style |normal:1.3|left:0()0()0()#ffffff:|OxiAddonsDP-title-P-top |5|5|5|OxiAddonsDP-title-P-bottom |10|10|10|OxiAddonsDP-title-P-left |5|5|5|OxiAddonsDP-title-P-right |5|5|5|OxiAddonsDP-excerpt-FS|16|16|16| OxiAddonsDP-excerpt-C |#9c9c9c|OxiAddonsDP-excerpt-F-family |Roboto|100|OxiAddonsDP-excerpt-F-style |normal:1.3|left:0()0()0()#ffffff:|OxiAddonsDP-excerpt-P-top |5|5|5|OxiAddonsDP-excerpt-P-bottom |15|15|15|OxiAddonsDP-excerpt-P-left |5|5|5|OxiAddonsDP-excerpt-P-right |5|5|5| OxiAddonsDP-Meta-S-PS |left|OxiAddonsDP-Meta-S-F-family |Poppins|100|OxiAddonsDP-Meta-S-F-style |normal:1.3|left:0()0()0()#ffffff:|OxiAddonsDP-Meta-S-P-top |10|10|10|OxiAddonsDP-Meta-S-P-bottom |10|10|10|OxiAddonsDP-Meta-S-P-left |10|10|10|OxiAddonsDP-Meta-S-P-right |10|10|10|OxiAddonsDP-Meta-N-FS|18|18|18| OxiAddonsDP-Meta-N-C |#2ba5ba| OxiAddonsDP-Meta-NH-C |#1cbfa4|OxiAddonsDP-Meta-D-FS|16|16|16| OxiAddonsDP-Meta-D-C |#b0b0b0|OxiAddonsDP-Meta-IMG-W|60|60|60|OxiAddonsDP-Meta-IMG-H|60|60|60|OxiAddonsDP-Meta-IMG-BR-top |100|100|100|OxiAddonsDP-Meta-IMG-BR-bottom |100|100|100|OxiAddonsDP-Meta-IMG-BR-left |100|100|100|OxiAddonsDP-Meta-IMG-BR-right |100|100|100| OxiAddonsDP-thumb |50| OxiAddonsDP-title-Hover-C |#43b6d9| OxiAddonsDP-show-tab ||OxiAddonsDP-Meta-name-p-top |5|5|5|OxiAddonsDP-Meta-name-p-bottom |0|0|0|OxiAddonsDP-Meta-name-p-left |5|5|5|OxiAddonsDP-Meta-name-p-right |5|5|5|OxiAddonsDP-Meta-date-p-top |0|0|0|OxiAddonsDP-Meta-date-p-bottom |5|5|5|OxiAddonsDP-Meta-date-p-left |5|5|5|OxiAddonsDP-Meta-date-p-right |5|5|5||||||OxiAddonsDP-post-type||#||post||#||OxiAddonsDP-post-author||#||1||#||OxiAddonsDP-category||#||||#||OxiAddonsDP-tags||#||||#||OxiAddonsDP-Exclude||#||||#||OxiAddonsDP-post-per-page ||#||3||#||OxiAddonsDP-post-offset ||#||||#||OxiAddonsDP-post-order-by ||#||ID||#||OxiAddonsDP-post-order-type ||#||asc||#||OxiAddonsDP-include||#||7{|}{|}5{|}{|}1||#||OxiAddonsDP-post-img-size ||#||medium||#||OxiAddonsDP-post-img-width ||#||400||#||OxiAddonsDP-post-img-height ||#||300||#|| ||#||',
            );
if ($oxiimpport == 'import') {
    ?>
    <div class="wrap">
        <?php
        echo OxiAddonsAdmAdminMenu($oxitype, '', '', 'yes');
    echo '<div class="oxi-addons-wrapper">
                <div class="oxi-addons-row">
                    <div class="oxi-addons-view-more-demo" style=" padding-top: 35px; padding-bottom: 35px; ">
                        <div class="oxi-addons-view-more-demo-data" >
                            <div class="oxi-addons-view-more-demo-icon">
                                <i class="fas fa-bullhorn oxi-icons"></i>
                            </div>
                            <div class="oxi-addons-view-more-demo-text">
                                <div class="oxi-addons-view-more-demo-heading">
                                    More Layouts
                                </div>
                                <div class="oxi-addons-view-more-demo-content">
                                    Thank you for using Shortcode Addons. As limitation of viewing Layouts or Design we added some layouts. Kindly check more  <a target="_blank" href="https://www.oxilab.org/shortcode-addons-features/' . str_replace('_', '-', $oxitype) . '" >' . oxi_addons_shortcode_name_converter($oxitype) . '</a> design from Oxilab.org. Copy <strong>export</strong> code and <strong>import</strong> it, get your preferable layouts.
                                </div>
                            </div>
                            <div class="oxi-addons-view-more-demo-button">
                                <a target="_blank" class="oxi-addons-more-layouts" href="https://www.oxilab.org/shortcode-addons-features/' . str_replace('_', '-', $oxitype) . '" >View layouts</a>
                            </div>
                        </div>
                    </div>
                </div>
           </div>'; ?>

        <div class="oxi-addons-wrapper">
            <div class="oxi-addons-row">
                <?php
                foreach ($file as $value) {
                    $expludedata = explode('OXIIMPORT', $value);
                    $datatrue = '';
                    foreach ($importstyle as $vals) {
                        if ($vals['name'] == $expludedata[2]) {
                            $datatrue = 'true';
                        }
                    }
                    if ($datatrue != 'true') {
                        $number = rand();
                        echo '<div class="oxi-addons-col-1"><div class="oxi-addons-style-preview"><div class="oxi-addons-style-preview-top oxi-addons-center">';
                        echo OxiDataAdminShortcode($oxitype, $value);
                        echo '</div>
                         <div class="oxi-addons-style-preview-bottom">
                            <div class="oxi-addons-style-preview-bottom-left">';
                        echo OxiDataAdminShortcodeName($value);
                        echo '       </div>';
                        echo '  <div class="oxi-addons-style-preview-bottom-right">
                                    <form method="post" style=" display: inline-block; ">
                                        ' . wp_nonce_field("oxi-addons-$expludedata[1]-style-active-nonce") . '
                                        <input type="hidden" name="oxiactivestyle" value="' . $expludedata[2] . '">
                                        <button class="btn btn-success" title="Active"  type="submit" value="Active" name="addonsstyleactive">Import Style</button>  
                                    </form> 
                                </div>';
                        echo '            </div>
                   </div>
                </div>';
                    }
                } ?>
            </div>
        </div>
    </div>

    <?php
} else {
                    $data = $wpdb->get_results("SELECT * FROM $table_name WHERE type = '$oxitype' ORDER BY id DESC", ARRAY_A); ?>
    <div class="wrap">
        <?php echo OxiAddonsAdmAdminMenu($oxitype, '', '', 'yes'); ?>
        <?php echo OxiAddonsAdmAdminShortcodeTable($data, $oxitype); ?>
        <div class="oxi-addons-wrapper">
            <div class="oxi-addons-row">
                <?php
                foreach ($file as $value) {
                    $expludedata = explode('OXIIMPORT', $value);
                    $datatrue = '';
                    foreach ($importstyle as $vals) {
                        if ($vals['name'] == $expludedata[2]) {
                            $datatrue = 'true';
                        }
                    }
                    if ($datatrue == 'true') {
                        $number = rand();
                        echo '<div class="oxi-addons-col-1" id="'.$expludedata[2].'"><div class="oxi-addons-style-preview"><div class="oxi-addons-style-preview-top oxi-addons-center">';
                        echo OxiDataAdminShortcode($oxitype, $value);
                        echo '</div>
                         <div class="oxi-addons-style-preview-bottom">
                            <div class="oxi-addons-style-preview-bottom-left">';
                        echo OxiDataAdminShortcodeName($value);
                        echo '       </div>';
                        echo OxiDataAdminShortcodeControl($number, $value, $freeimport);
                        echo '            </div>
                   </div>
                </div>';
                    }
                } ?>
                <div class="oxi-addons-col-1 oxi-import">
                    <div class="oxi-addons-style-preview">
                        <div class="oxilab-admin-style-preview-top">
                            <a href="<?php echo admin_url("admin.php?page=oxi-addons&oxitype=$oxitype&oxiimpport=import"); ?>">
                                <div class="oxilab-admin-add-new-item">
                                    <span>
                                        <i class="fas fa-plus-circle oxi-icons"></i>  
                                        Add More Templates
                                    </span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
    echo OxiDataAdminShortcodeModal($oxitype);
                }
