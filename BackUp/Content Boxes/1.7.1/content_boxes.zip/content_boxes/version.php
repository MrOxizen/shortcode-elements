<?php
/*
  Plugin Name: Shortcode Addons
  Version: 1.7.1
 */

return array(1.7, 'Content Elements', true);
