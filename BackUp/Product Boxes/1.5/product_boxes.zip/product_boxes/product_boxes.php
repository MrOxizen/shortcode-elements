<?php
if (!defined('ABSPATH')) {
    exit;
}

$oxitype = sanitize_text_field($_GET['oxitype']);
$oxiimpport = '';
if (!empty($_GET['oxiimpport'])) {
    $oxiimpport = sanitize_text_field($_GET['oxiimpport']);
}

oxi_addons_user_capabilities();
OxiDataAdminImport($oxitype);
global $wpdb;
$table_name = $wpdb->prefix . 'oxi_div_style';
$table_import = $wpdb->prefix . 'oxi_div_import';
$importstyle = $wpdb->get_results("SELECT * FROM $table_import WHERE type = '$oxitype' ORDER BY id DESC", ARRAY_A);
$freeimport = array('style-1');
if (count($importstyle) < 1) {
    foreach ($freeimport as $value) {
        $wpdb->query($wpdb->prepare("INSERT INTO {$table_import} (type, name) VALUES (%s, %s )", array($oxitype, $value)));
    }
    $js = 'location.reload();';
    wp_add_inline_script('oxi-addons-vendor', $js);
}
$file = Array(
    'Style 1 layout 1OXIIMPORTproduct_boxesOXIIMPORTstyle-1OXIIMPORToxi-addons-preview-BG |rgba(255,255,255,1.00)|OxiAddonsProductBoxes-rows |oxi-addons-lg-col-3|oxi-addons-md-col-2|oxi-addons-xs-col-1|OxiAddonsProductBoxes-G-P-top |10|10|10|OxiAddonsProductBoxes-G-P-bottom |10|10|10|OxiAddonsProductBoxes-G-P-left |10|10|10|OxiAddonsProductBoxes-G-P-right |10|10|10|OxiAddonsProductBoxes-G-M-top |5|5|5|OxiAddonsProductBoxes-G-M-bottom |5|5|5|OxiAddonsProductBoxes-G-M-left |5|5|5|OxiAddonsProductBoxes-G-M-right |5|5|5| OxiAddonsProductBoxes-animation||0.5:false:false:500:10:0.2|0.5//||OxiAddonsProductBoxes-BS |rgba(255, 255, 255, 1)|1|4|7|1|OxiAddonsProductBoxes-O-H-FS |20|20|20|OxiAddonsProductBoxes-O-H-F-family |Open+Sans|600|OxiAddonsProductBoxes-O-H-F-style |normal:1.3|center:0()0()0()#ffffff:| OxiAddonsProductBoxes-O-H-C |#424242|OxiAddonsProductBoxes-O-H-P-top |10|10|10|OxiAddonsProductBoxes-O-H-P-bottom |10|10|10|OxiAddonsProductBoxes-O-H-P-left |10|10|10|OxiAddonsProductBoxes-O-H-P-right |10|10|10| OxiAddonsProductBoxes-O-H-Animation|tada|0.5:false:false:500:10:0.2|0.5//||OxiAddonsProductBoxes-T-H-FS |32|32|32|OxiAddonsProductBoxes-T-H-F-family |Open+Sans|bold|OxiAddonsProductBoxes-T-H-F-style |normal:1.3|center:0()0()0()#ffffff:| OxiAddonsProductBoxes-T-H-C |#596627|OxiAddonsProductBoxes-T-H-P-top |10|10|10|OxiAddonsProductBoxes-T-H-P-bottom |10|10|10|OxiAddonsProductBoxes-T-H-P-left |10|10|10|OxiAddonsProductBoxes-T-H-P-right |10|10|10| OxiAddonsProductBoxes-T-H-Animation|wobble|0.5:false:false:500:10:0.2|0.5//||OxiAddonsProductBoxes-SD-FS |16|16|16|OxiAddonsProductBoxes-SD-F-family |Open+Sans|300|OxiAddonsProductBoxes-SD-F-style |normal:1.3|center:0()0()0()#ffffff:| OxiAddonsProductBoxes-SD-C |#000000|OxiAddonsProductBoxes-SD-P-top |10|10|10|OxiAddonsProductBoxes-SD-P-bottom |40|40|40|OxiAddonsProductBoxes-SD-P-left |10|10|10|OxiAddonsProductBoxes-SD-P-right |10|10|10| OxiAddonsProductBoxes-SD-Animation|shake|0.5:false:false:500:10:0.2|0.5//|| OxiAddonsProductBoxes-B-PS |center| OxiAddonsProductBoxes-B-Tab ||OxiAddonsProductBoxes-B-P-top |10|8|7|OxiAddonsProductBoxes-B-P-bottom |10|8|7|OxiAddonsProductBoxes-B-P-left |30|25|25|OxiAddonsProductBoxes-B-P-right |30|25|25|OxiAddonsProductBoxes-B-M-top |5|5|5|OxiAddonsProductBoxes-B-M-bottom |5|5|5|OxiAddonsProductBoxes-B-M-left |5|5|5|OxiAddonsProductBoxes-B-M-right |5|5|5| OxiAddonsProductBoxes-B-BG |rgba(117, 117, 117, 1)| OxiAddonsProductBoxes-B-TC |#ffffff|OxiAddonsProductBoxes-B-FS |16|16|16|OxiAddonsProductBoxes-B-F-family |Montserrat|bold|OxiAddonsProductBoxes-B-F-style |normal|::|OxiAddonsProductBoxes-B-BR-top |50|50|50|OxiAddonsProductBoxes-B-BR-bottom |50|50|50|OxiAddonsProductBoxes-B-BR-left |50|50|50|OxiAddonsProductBoxes-B-BR-right |50|50|50|OxiAddonsProductBoxes-B-B |0|dotted|| OxiAddonsProductBoxes-B-BC |#7aff95|OxiAddonsProductBoxes-B-BS |rgba(255, 255, 255, 1)|0|0|0|0| OxiAddonsProductBoxes-B-Animation||0.5:false:false:500:10:0.2|0.5//|| OxiAddonsProductBoxes-B-HTC |#e8b351| OxiAddonsProductBoxes-B-HBG |rgba(92, 105, 93, 1)| OxiAddonsProductBoxes-B-HBC |#14ba3e| OxiAddonsProductBoxes-pb-bg |rgba(128, 109, 109, 0.44)|OxiAddonsProductBoxes-B-HBS |rgba(128, 109, 109, 0.44)|||||OxiAddonsProductBoxes-pb-width |350|350|350||##OXISTYLE##OxiAddonsProductBoxes-BG ||#||https://www.oxilab.org/wp-content/uploads/2019/02/prcc15-571x714.jpg||#|| OxiAddonsProductBoxes-O-H-TB ||#||Quality Products from Stall to Your Door||#|| OxiAddonsProductBoxes-T-H-TB ||#||Seasonal Picked||#|| OxiAddonsProductBoxes-SD-TA ||#||Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean congue ornare est, non ultricies ante. Nunc augue metus, venenatis sit amet auctor sagittis, porttitor quis mauris. Sed tristique rhoncus accumsan.||#|| OxiAddonsProductBoxes-B-BT ||#||More About us||#|| OxiAddonsProductBoxes-B-BL ||#||#||#|| ||#||##OXIDATA##OxiAddonsProductBoxes-BG ||#||https://www.oxilab.org/wp-content/uploads/2019/02/5_3-571x714.jpg||#|| OxiAddonsProductBoxes-O-H-TB ||#||DISCOVER THEM ALL||#|| OxiAddonsProductBoxes-T-H-TB ||#||THIS SEASON <br> BOMBER SHOES||#|| OxiAddonsProductBoxes-SD-TA ||#||Organic foods are foods produced by methods that comply with the standards of organic farming. It supports cycling of resources, ecological balance, and conserve biodiversity.||#|| OxiAddonsProductBoxes-B-BT ||#||DISCOVER MORE||#|| OxiAddonsProductBoxes-B-BL ||#||#||#|| ||#||##OXIDATA##OxiAddonsProductBoxes-BG ||#||https://www.oxilab.org/wp-content/uploads/2019/02/Printed-color-block-T-shirt2-571x714.jpg||#|| OxiAddonsProductBoxes-O-H-TB ||#||DISCOVER THEM ALL||#|| OxiAddonsProductBoxes-T-H-TB ||#||THIS SEASON <br> BOMBER JACKETS||#|| OxiAddonsProductBoxes-SD-TA ||#||Organic foods are foods produced by methods that comply with the standards of organic farming. It supports cycling of resources, ecological balance, and conserve biodiversity.||#|| OxiAddonsProductBoxes-B-BT ||#||DISCOVER MORE||#|| OxiAddonsProductBoxes-B-BL ||#||#||#|| ||#||##OXIDATA##',
    'Style 1 layout 2OXIIMPORTproduct_boxesOXIIMPORTstyle-1OXIIMPORToxi-addons-preview-BG |rgba(255,255,255,1.00)|OxiAddonsProductBoxes-rows |oxi-addons-lg-col-3|oxi-addons-md-col-1|oxi-addons-xs-col-1|OxiAddonsProductBoxes-G-P-top |10|10|10|OxiAddonsProductBoxes-G-P-bottom |10|10|10|OxiAddonsProductBoxes-G-P-left |10|10|10|OxiAddonsProductBoxes-G-P-right |10|10|10|OxiAddonsProductBoxes-G-M-top |5|5|5|OxiAddonsProductBoxes-G-M-bottom |5|5|5|OxiAddonsProductBoxes-G-M-left |10|5|5|OxiAddonsProductBoxes-G-M-right |10|5|5| OxiAddonsProductBoxes-animation||.5:false:false:500:10:0.2|.5//||OxiAddonsProductBoxes-BS |rgba(194, 194, 194, 0.71)|2|5|13|2|OxiAddonsProductBoxes-O-H-FS |20|18|16|OxiAddonsProductBoxes-O-H-F-family |Open+Sans|600|OxiAddonsProductBoxes-O-H-F-style |normal:1.3|left:0()0()0()#ffffff:| OxiAddonsProductBoxes-O-H-C |#e6e6e6|OxiAddonsProductBoxes-O-H-P-top |10|10|10|OxiAddonsProductBoxes-O-H-P-bottom |10|10|10|OxiAddonsProductBoxes-O-H-P-left |10|0|0|OxiAddonsProductBoxes-O-H-P-right |10|0|0| OxiAddonsProductBoxes-O-H-Animation|tada|.5:false:false:500:10:0.2|0.5//||OxiAddonsProductBoxes-T-H-FS |32|28|24|OxiAddonsProductBoxes-T-H-F-family |Open+Sans|bold|OxiAddonsProductBoxes-T-H-F-style |normal:1.3|left:0()0()0()#ffffff:| OxiAddonsProductBoxes-T-H-C |#adadad|OxiAddonsProductBoxes-T-H-P-top |10|10|10|OxiAddonsProductBoxes-T-H-P-bottom |10|10|10|OxiAddonsProductBoxes-T-H-P-left |10|0|0|OxiAddonsProductBoxes-T-H-P-right |10|0|0| OxiAddonsProductBoxes-T-H-Animation|wobble|.5:false:false:500:10:0.2|.5//||OxiAddonsProductBoxes-SD-FS |16|16|16|OxiAddonsProductBoxes-SD-F-family |Open+Sans|300|OxiAddonsProductBoxes-SD-F-style |normal:1.3|left:0()0()0()#ffffff:| OxiAddonsProductBoxes-SD-C |#2a1057|OxiAddonsProductBoxes-SD-P-top |20|20|20|OxiAddonsProductBoxes-SD-P-bottom |30|30|30|OxiAddonsProductBoxes-SD-P-left |10|0|0|OxiAddonsProductBoxes-SD-P-right |10|0|-1| OxiAddonsProductBoxes-SD-Animation|shake|.5:false:false:500:10:0.2|.5//|| OxiAddonsProductBoxes-B-PS |center| OxiAddonsProductBoxes-B-Tab ||OxiAddonsProductBoxes-B-P-top |10|8|7|OxiAddonsProductBoxes-B-P-bottom |10|8|7|OxiAddonsProductBoxes-B-P-left |30|25|25|OxiAddonsProductBoxes-B-P-right |30|25|25|OxiAddonsProductBoxes-B-M-top |20|20|20|OxiAddonsProductBoxes-B-M-bottom |5|5|5|OxiAddonsProductBoxes-B-M-left |5|5|5|OxiAddonsProductBoxes-B-M-right |5|5|5| OxiAddonsProductBoxes-B-BG |rgba(0,110,53,1.00)| OxiAddonsProductBoxes-B-TC |#ffffff|OxiAddonsProductBoxes-B-FS |16|16|16|OxiAddonsProductBoxes-B-F-family |Montserrat|bold|OxiAddonsProductBoxes-B-F-style |normal|::|OxiAddonsProductBoxes-B-BR-top |50|50|50|OxiAddonsProductBoxes-B-BR-bottom |50|50|50|OxiAddonsProductBoxes-B-BR-left |50|50|50|OxiAddonsProductBoxes-B-BR-right |50|50|50|OxiAddonsProductBoxes-B-B |0|dotted|| OxiAddonsProductBoxes-B-BC |#7aff95|OxiAddonsProductBoxes-B-BS |rgba(255, 255, 255, 1)|0|0|0|0| OxiAddonsProductBoxes-B-Animation||.5:false:false:500:10:0.2|.5//|| OxiAddonsProductBoxes-B-HTC |#e8b351| OxiAddonsProductBoxes-B-HBG |rgba(92, 105, 93, 1)| OxiAddonsProductBoxes-B-HBC |#14ba3e| OxiAddonsProductBoxes-pb-bg |linear-gradient(90deg, rgba(65,163,85,0.41) 0%,rgba(17,120,9,0.5) 0%,rgba(0,145,135,0.5) 0%,rgba(18,163,117,0.5) 0%,rgba(145,85,6,0.50) 0%,rgba(0,122,6,0.54) 100%,rgba(10,102,91,0.29) 100%,rgba(79,0,0,0.5) 100%,rgba(125,70,122,0.23) 100%,rgba(152,179,46,0.5) 100%)|OxiAddonsProductBoxes-B-HBS |rgba(128, 109, 109, 0.44)|||||OxiAddonsProductBoxes-pb-width |350|18|16||##OXISTYLE##OxiAddonsProductBoxes-BG ||#||https://www.oxilab.org/wp-content/uploads/2019/01/be62998b06851c4f1c14ec32894ca2ab.jpg_720x720q75.jpg||#|| OxiAddonsProductBoxes-O-H-TB ||#||Quality Products||#|| OxiAddonsProductBoxes-T-H-TB ||#||Seasonal Picked||#|| OxiAddonsProductBoxes-SD-TA ||#||Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean congue ornare est, non ultricies ante.||#|| OxiAddonsProductBoxes-B-BT ||#||More About us||#|| OxiAddonsProductBoxes-B-BL ||#||#||#|| ||#||##OXIDATA##OxiAddonsProductBoxes-BG ||#||https://www.oxilab.org/wp-content/uploads/2019/01/22ab18f5d0ea97d89cad52733de68fe2.jpg_720x720q75.jpg||#|| OxiAddonsProductBoxes-O-H-TB ||#||DISCOVER THEM ALL||#|| OxiAddonsProductBoxes-T-H-TB ||#||THIS SEASON||#|| OxiAddonsProductBoxes-SD-TA ||#||Organic foods are foods produced by methods that comply with the standards of organic farming.||#|| OxiAddonsProductBoxes-B-BT ||#||DISCOVER MORE||#|| OxiAddonsProductBoxes-B-BL ||#||#||#|| ||#||##OXIDATA##OxiAddonsProductBoxes-BG ||#||https://www.oxilab.org/wp-content/uploads/2019/01/HTB1gLJoalsmBKNjSZFsq6yXSVXa7.jpg||#|| OxiAddonsProductBoxes-O-H-TB ||#||DISCOVER THEM ALL||#|| OxiAddonsProductBoxes-T-H-TB ||#||THIS SEASON||#|| OxiAddonsProductBoxes-SD-TA ||#||Organic foods are foods produced by methods that comply with the standards of organic farming.||#|| OxiAddonsProductBoxes-B-BT ||#||DISCOVER MORE||#|| OxiAddonsProductBoxes-B-BL ||#||#||#|| ||#||##OXIDATA##',
    'Style 2OXIIMPORTproduct_boxesOXIIMPORTstyle-2OXIIMPORToxi-addons-preview-BG ||OxiAddonsProductBoxes-rows |oxi-addons-lg-col-3|oxi-addons-md-col-1|oxi-addons-xs-col-1| OxiAddonsProductBoxes-G-BG |rgba(255,255,255,1.00)|OxiAddonsProductBoxes-G-B |1|solid|| OxiAddonsProductBoxes-G-BC |#c9c9c9|OxiAddonsProductBoxes-G-P-top |0|0|0|OxiAddonsProductBoxes-G-P-bottom |0|0|0|OxiAddonsProductBoxes-G-P-left |0|0|0|OxiAddonsProductBoxes-G-P-right |0|0|0|OxiAddonsProductBoxes-G-M-top |5|5|5|OxiAddonsProductBoxes-G-M-bottom |5|5|5|OxiAddonsProductBoxes-G-M-left |5|5|5|OxiAddonsProductBoxes-G-M-right |5|5|5| OxiAddonsProductBoxes-animation||0.5:false:false:500:10:0.2|0.5//|OxiAddonsProductBoxes-BS |rgba(161, 161, 161, 1)|0|5|10|-3| OxiAddonsProductBoxes-title-Tab ||OxiAddonsProductBoxes-title-FS |18|18|18| OxiAddonsProductBoxes-title-C |#591d1d|OxiAddonsProductBoxes-title-F-family |Open+Sans|500|OxiAddonsProductBoxes-title-F-style |normal:1.3|center:0()0()0()#ffffff:|OxiAddonsProductBoxes-title-P-top |15|15|15|OxiAddonsProductBoxes-title-P-bottom |5|5|5|OxiAddonsProductBoxes-title-P-left |0|0|0|OxiAddonsProductBoxes-title-P-right |0|0|0|OxiAddonsProductBoxes-price-FS |18|18|18| OxiAddonsProductBoxes-price-C |#b55959|OxiAddonsProductBoxes-price-F-family |Montserrat|normal|OxiAddonsProductBoxes-price-F-style |normal:1.3|center:0()0()0()#ffffff:|OxiAddonsProductBoxes-price-P-top |5|5|5|OxiAddonsProductBoxes-price-P-bottom |15|15|15|OxiAddonsProductBoxes-price-P-left |0|0|0|OxiAddonsProductBoxes-price-P-right |0|0|0| OxiAddonsProductBoxes-B-Tab ||OxiAddonsProductBoxes-B-P-top |10|10|10|OxiAddonsProductBoxes-B-P-bottom |10|0|10|OxiAddonsProductBoxes-B-P-left |10|0|10|OxiAddonsProductBoxes-B-P-right |10|0|10|OxiAddonsProductBoxes-B-FS |16|16|16| OxiAddonsProductBoxes-B-TC |#ffffff| OxiAddonsProductBoxes-B-BG |rgba(38,38,38,1.00)|OxiAddonsProductBoxes-B-F-family |Montserrat|bold|OxiAddonsProductBoxes-B-F-style |normal:1.3|center:0()0()0()#ffffff:| OxiAddonsProductBoxes-B-HTC |#cfcfcf| OxiAddonsProductBoxes-B-HBG |rgba(107,107,107,1.00)|OxiAddonsProductBoxes-CB-B |solid|#cccccc|OxiAddonsProductBoxes-CB-BW-top |3|3|3|OxiAddonsProductBoxes-CB-BW-bottom |0|0|0|OxiAddonsProductBoxes-CB-BW-left |0|0|0|OxiAddonsProductBoxes-CB-BW-right |0|0|0| OxiAddonsProductBoxes-title-HC |#591d1d|OxiAddonsProductBoxes-pb-width |350|350|350||##OXISTYLE##OxiAddonsProductBoxes-F-BG ||#||https://www.oxilab.org/wp-content/uploads/2019/05/shirt1.jpg||#|| OxiAddonsProductBoxes-H-BG ||#||https://www.oxilab.org/wp-content/uploads/2019/05/shirt3.jpg||#|| OxiAddonsProductBoxes-title-TB ||#||DEFAULT TITLE||#|| OxiAddonsProductBoxes-title-L ||#||#||#|| OxiAddonsProductBoxes-price-TB ||#||$78.00||#|| OxiAddonsProductBoxes-B-BT ||#||Order now||#|| OxiAddonsProductBoxes-B-BL ||#||#||#|| ||#||##OXIDATA##OxiAddonsProductBoxes-F-BG ||#||https://www.oxilab.org/wp-content/uploads/2019/05/81Spit4yXuL._UL1500_.jpg||#|| OxiAddonsProductBoxes-H-BG ||#||https://www.oxilab.org/wp-content/uploads/2019/05/il_570xN.1596485311_sa0b_large.jpg||#|| OxiAddonsProductBoxes-title-TB ||#||DEFAULT TITLE||#|| OxiAddonsProductBoxes-title-L ||#||#||#|| OxiAddonsProductBoxes-price-TB ||#||$60.00||#|| OxiAddonsProductBoxes-B-BT ||#||Order now||#|| OxiAddonsProductBoxes-B-BL ||#||#||#|| ||#||##OXIDATA##OxiAddonsProductBoxes-F-BG ||#||https://www.oxilab.org/wp-content/uploads/2019/05/shirt4.jpg||#|| OxiAddonsProductBoxes-H-BG ||#||https://www.oxilab.org/wp-content/uploads/2019/05/shirt5.jpg||#|| OxiAddonsProductBoxes-title-TB ||#||DEFAULT TITLE||#|| OxiAddonsProductBoxes-title-L ||#||#||#|| OxiAddonsProductBoxes-price-TB ||#||$78.00||#|| OxiAddonsProductBoxes-B-BT ||#||Order now||#|| OxiAddonsProductBoxes-B-BL ||#||#||#|| ||#||##OXIDATA##',
    'Style 3OXIIMPORTproduct_boxesOXIIMPORTstyle-3OXIIMPORToxi-addons-preview-BG ||OxiAddonsProductBoxes-rows |oxi-addons-lg-col-3|oxi-addons-md-col-2|oxi-addons-xs-col-1| OxiAddonsProductBoxes-G-BG |rgba(255, 255, 255, 1)|OxiAddonsProductBoxes-G-B |1|none|| OxiAddonsProductBoxes-G-BC |#de7a7a|OxiAddonsProductBoxes-G-P-top |5|5|5|OxiAddonsProductBoxes-G-P-bottom |5|5|5|OxiAddonsProductBoxes-G-P-left |5|5|5|OxiAddonsProductBoxes-G-P-right |5|5|5|OxiAddonsProductBoxes-G-M-top |5|5|5|OxiAddonsProductBoxes-G-M-bottom |5|5|5|OxiAddonsProductBoxes-G-M-left |5|5|5|OxiAddonsProductBoxes-G-M-right |5|5|5| OxiAddonsProductBoxes-animation||.5:false:false:500:10:0.2|.5//|OxiAddonsProductBoxes-BS |rgba(219, 219, 219, 1)|0|4|8|0|OxiAddonsProductBoxes-title-FS |18|18|18| OxiAddonsProductBoxes-title-C |#ffffff|OxiAddonsProductBoxes-title-F-family |Montserrat|500|OxiAddonsProductBoxes-title-F-style |normal:1.3|center:0()0()0()#ffffff:|OxiAddonsProductBoxes-title-P-top |0|0|0|OxiAddonsProductBoxes-title-P-bottom |15|15|15|OxiAddonsProductBoxes-title-P-left |0|0|0|OxiAddonsProductBoxes-title-P-right |0|0|0|OxiAddonsProductBoxes-price-FS |16|16|16| OxiAddonsProductBoxes-price-C |#ffffff|OxiAddonsProductBoxes-price-F-family |Roboto|600|OxiAddonsProductBoxes-price-F-style |normal:1.3|center:0()0()0()#ffffff:|OxiAddonsProductBoxes-price-P-top |5|5|5|OxiAddonsProductBoxes-price-P-bottom |15|15|15|OxiAddonsProductBoxes-price-P-left |0|0|0|OxiAddonsProductBoxes-price-P-right |0|0|0| OxiAddonsBanner-B-Tab ||OxiAddonsBanner-B-P-top |10|10|10|OxiAddonsBanner-B-P-bottom |10|10|10|OxiAddonsBanner-B-P-left |25|25|25|OxiAddonsBanner-B-P-right |25|25|25|OxiAddonsBanner-B-M-top |10|10|10|OxiAddonsBanner-B-M-bottom |1|1|1|OxiAddonsBanner-B-M-left |1|1|1|OxiAddonsBanner-B-M-right |1|1|1| OxiAddonsBanner-B-PS |center|OxiAddonsBanner-B-FS |16|16|16| OxiAddonsBanner-B-TC |#ffffff| OxiAddonsBanner-B-BG |rgba(93, 128, 145, 0)|OxiAddonsBanner-B-B |2|solid|| OxiAddonsBanner-B-BC |#ffffff|OxiAddonsBanner-B-F-family |Montserrat|100|OxiAddonsBanner-B-F-style |normal:1.3|left:0()0()0()#ffffff:|OxiAddonsBanner-B-BR-top |50|50|50|OxiAddonsBanner-B-BR-bottom |50|50|50|OxiAddonsBanner-B-BR-left |50|50|50|OxiAddonsBanner-B-BR-right |50|50|50|OxiAddonsBanner-B-BS |rgba(176, 176, 176, 1)|0|0|0|0| OxiAddonsBanner-B-HTC |#ffffff| OxiAddonsBanner-B-HBG |rgba(41, 37, 37, 1)| OxiAddonsBanner-B-HBC |#ffffff|OxiAddonsBanner-B-HBS |rgba(255, 255, 255, 1)|0|0|0|0| OxiAddonsProductBoxes-Over-BG |rgba(0, 0, 0, 0.4)|OxiAddonsProductBoxes-pb-width |350|350|350||##OXISTYLE##OxiAddonsProductBoxes-BG ||#||https://www.oxilab.org/wp-content/uploads/2019/05/shraddha-skyblue-long-designer-skirt-8990-800x800.jpg||#|| OxiAddonsProductBoxes-title-TB ||#||DEFAULT TITLE||#|| OxiAddonsProductBoxes-price-TB ||#||$65.00||#|| OxiAddonsProductBoxes-B-BT ||#||Order Now||#|| OxiAddonsProductBoxes-B-BL ||#||#||#|| ||#||##OXIDATA##OxiAddonsProductBoxes-BG ||#||https://www.oxilab.org/wp-content/uploads/2019/02/45911684_566822337098341_6383598209885731730_n.jpg||#|| OxiAddonsProductBoxes-title-TB ||#||DEFAULT TITLE||#|| OxiAddonsProductBoxes-price-TB ||#||$80||#|| OxiAddonsProductBoxes-B-BT ||#||Order Now||#|| OxiAddonsProductBoxes-B-BL ||#||#||#|| ||#||##OXIDATA##OxiAddonsProductBoxes-BG ||#||https://www.oxilab.org/wp-content/uploads/2019/02/prcc15-571x714.jpg||#|| OxiAddonsProductBoxes-title-TB ||#||DEFAULT TITLE||#|| OxiAddonsProductBoxes-price-TB ||#||$80||#|| OxiAddonsProductBoxes-B-BT ||#||Order Now||#|| OxiAddonsProductBoxes-B-BL ||#||#||#|| ||#||##OXIDATA##',
);
if ($oxiimpport == 'import') {
    ?>
    <div class="wrap">
        <?php
        echo OxiAddonsAdmAdminMenu($oxitype, '', '', 'yes');
        echo '<div class="oxi-addons-wrapper">
                <div class="oxi-addons-row">
                    <div class="oxi-addons-view-more-demo" style=" padding-top: 35px; padding-bottom: 35px; ">
                        <div class="oxi-addons-view-more-demo-data" >
                            <div class="oxi-addons-view-more-demo-icon">
                                <i class="fas fa-bullhorn oxi-icons"></i>
                            </div>
                            <div class="oxi-addons-view-more-demo-text">
                                <div class="oxi-addons-view-more-demo-heading">
                                    More Layouts
                                </div>
                                <div class="oxi-addons-view-more-demo-content">
                                    Thank you for using Shortcode Addons. As limitation of viewing Layouts or Design we added some layouts. Kindly check more  <a target="_blank" href="https://www.oxilab.org/shortcode-addons-features/' . str_replace('_', '-', $oxitype) . '" >' . oxi_addons_shortcode_name_converter($oxitype) . '</a> design from Oxilab.org. Copy <strong>export</strong> code and <strong>import</strong> it, get your preferable layouts.
                                </div>
                            </div>
                            <div class="oxi-addons-view-more-demo-button">
                                <a target="_blank" class="oxi-addons-more-layouts" href="https://www.oxilab.org/shortcode-addons-features/' . str_replace('_', '-', $oxitype) . '" >View layouts</a>
                            </div>
                        </div>
                    </div>
                </div>
           </div>';
        ?>

        <div class="oxi-addons-wrapper">
            <div class="oxi-addons-row">
                <?php
                foreach ($file as $value) {
                    $expludedata = explode('OXIIMPORT', $value);
                    $datatrue = '';
                    foreach ($importstyle as $vals) {
                        if ($vals['name'] == $expludedata[2]) {
                            $datatrue = 'true';
                        }
                    }
                    if ($datatrue != 'true') {
                        $number = rand();
                        echo '<div class="oxi-addons-col-1"><div class="oxi-addons-style-preview"><div class="oxi-addons-style-preview-top oxi-addons-center">';
                        echo OxiDataAdminShortcode($oxitype, $value);
                        echo '</div>
                         <div class="oxi-addons-style-preview-bottom">
                            <div class="oxi-addons-style-preview-bottom-left">';
                        echo OxiDataAdminShortcodeName($value);
                        echo '       </div>';
                        echo '  <div class="oxi-addons-style-preview-bottom-right">
                                    <form method="post" style=" display: inline-block; ">
                                        ' . wp_nonce_field("oxi-addons-$expludedata[1]-style-active-nonce") . '
                                        <input type="hidden" name="oxiactivestyle" value="' . $expludedata[2] . '">
                                        <button class="btn btn-success" title="Active"  type="submit" value="Active" name="addonsstyleactive">Import Style</button>  
                                    </form> 
                                </div>';
                        echo '            </div>
                   </div>
                </div>';
                    }
                }
                ?>
            </div>
        </div>
    </div>

<?php
} else {
    $data = $wpdb->get_results("SELECT * FROM $table_name WHERE type = '$oxitype' ORDER BY id DESC", ARRAY_A);
    ?>
    <div class="wrap">
        <?php echo OxiAddonsAdmAdminMenu($oxitype, '', '', 'yes'); ?>
        <?php echo OxiAddonsAdmAdminShortcodeTable($data, $oxitype); ?>
        <div class="oxi-addons-wrapper">
            <div class="oxi-addons-row">
                <?php
                foreach ($file as $value) {
                    $expludedata = explode('OXIIMPORT', $value);
                    $datatrue = '';
                    foreach ($importstyle as $vals) {
                        if ($vals['name'] == $expludedata[2]) {
                            $datatrue = 'true';
                        }
                    }
                    if ($datatrue == 'true') {
                        $number = rand();
                        echo '<div class="oxi-addons-col-1" id="' . $expludedata[2] . '"><div class="oxi-addons-style-preview"><div class="oxi-addons-style-preview-top oxi-addons-center">';
                        echo OxiDataAdminShortcode($oxitype, $value);
                        echo '</div>
                         <div class="oxi-addons-style-preview-bottom">
                            <div class="oxi-addons-style-preview-bottom-left">';
                        echo OxiDataAdminShortcodeName($value);
                        echo '       </div>';
                        echo OxiDataAdminShortcodeControl($number, $value, $freeimport);
                        echo '            </div>
                   </div>
                </div>';
                    }
                }
                ?>
                <div class="oxi-addons-col-1 oxi-import">
                    <div class="oxi-addons-style-preview">
                        <div class="oxilab-admin-style-preview-top">
                            <a href="<?php echo admin_url("admin.php?page=oxi-addons&oxitype=$oxitype&oxiimpport=import"); ?>">
                                <div class="oxilab-admin-add-new-item">
                                    <span>
                                        <i class="fas fa-plus-circle oxi-icons"></i>
                                        Add More Templates
                                    </span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
    echo OxiDataAdminShortcodeModal($oxitype);
}







