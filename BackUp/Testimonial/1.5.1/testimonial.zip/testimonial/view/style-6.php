<?php

if (!defined('ABSPATH'))
    exit;

function oxi_testimonial_style_6_shortcode($styledata = FALSE, $listdata = FALSE, $user = 'user') {
    $stylename = $styledata['style_name'];
    $oxiid = $styledata['id'];
    $stylefiles = explode('||#||', $styledata['css']);
    $styledata = explode('|', $stylefiles[0]);
    $css = '';
    echo '<div class="oxi-addons-container"><div class="oxi-addons-row">';
    foreach ($listdata as $value) {
        $data = explode('||#||', $value['files']);
        $image = $info = $rating = $name = $company =  '';
        if ($data[1] != '') {
            $image = '
                <div class="oxi-testimonials-style-' . $oxiid . '-left">
                    <div class="oxi-testimonials-style-' . $oxiid . '-image">
                        <img src="' . OxiAddonsUrlConvert($data[1]) . '">
                    </div> 
                </div>
            ';
        }
        if ($data[5] != '') {
            $info = '
                  <div class="oxi-testimonials-style-' . $oxiid . '-info">
                        <i class="fa fa-quote-left" aria-hidden="true"></i>
                        ' . OxiAddonsTextConvert($data[5]) . '
                        <i class="fa fa-quote-right" aria-hidden="true"></i>
                    </div>
            ';
        }
        if ($data[5] != '') {
            $rating = '
                    <div class="oxi-testimonials-style-' . $oxiid . '-rating">
                        ' . OxiAddonsPublicRate($data[5]) . '                                
                     </div>
            ';
        }
        if ($data[3] != '') {
            $name = '
                      <div class="oxi-testimonials-style-' . $oxiid . '-name">
                            ' . OxiAddonsTextConvert($data[3]) . '
                        </div>
            ';
        }
        if ($data[9] != '') {
            $company = '
                   <div class="oxi-testimonials-style-' . $oxiid . '-working">
                        <a href="' . $data[7] . '" target="' . $styledata[31] . '">' . OxiAddonsTextConvert($data[9]) . '</a>
                    </div>
            ';
        }
        echo ' <div class="oxi-testimonials-' . $oxiid . '-padding ' . OxiAddonsItemRows($styledata, 3) . ' ' . OxiAddonsAdminDefine($user) . '" ' . OxiAddonsAnimation($styledata, 33) . ' >
                    <div class="oxi-testimonials-item-' . $oxiid . '">
                            <div class="oxi-testimonials-style-' . $oxiid . ' ' . $styledata[11] . '">                                
                               '. $info .'
                               '. $image .'
                               
                                <div class="oxi-testimonials-style-' . $oxiid . '-right">
                                   '. $name .'
                                   '. $company .' 
                                </div>
                            </div>
                        </div>   ';
        if ($user == 'admin') {
            echo '  <div class="oxi-addons-admin-absulote">
                            <div class="oxi-addons-admin-absulate-edit">
                                <form method="post"> ' . wp_nonce_field("OxiAddonsListFileEdittestimonialdata") . '
                                    <input type="hidden" name="oxi-item-id" value="' . $value['id'] . '">
                                    <button class="btn btn-primary" type="submit" value="edit" name="OxiAddonsListFileEdit">Edit</button>
                                </form>
                            </div>
                            <div class="oxi-addons-admin-absulate-delete">
                                <form method="post">  ' . wp_nonce_field("OxiAddonsListFileDeletetestimonialdata") . '
                                    <input type="hidden" name="oxi-item-id" value="' . $value['id'] . '">
                                    <button class="btn btn-danger " type="submit" value="delete" name="OxiAddonsListFileDelete">Delete</button>
                                </form>
                            </div>
                        </div>';
        }
        echo '</div>';
    }
    echo '</div></div>';
    $css .= '  .oxi-addons-container .oxi-testimonials-' . $oxiid . '-padding{
                padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 15) . '; 
            }
             .oxi-addons-container .oxi-testimonials-item-' . $oxiid . '{
                position: relative;
                max-width: ' . $styledata[7] . 'px;
                width: 100%;
                margin: 0 auto;
            }
             .oxi-addons-container .oxi-testimonials-style-' . $oxiid . '{
                width: 100%;
                position: relative;
                float: left;
                text-align: left;
            }            
             .oxi-addons-container .oxi-testimonials-style-' . $oxiid . '-info{
                padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 124) . ';
                width: 100%;
                float: left;                
                font-size: ' . $styledata[96] . 'px;                
                text-align: left;
                background-color: ' . $styledata[13] . ';
                color: ' . $styledata[100] . ';
                border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 108) . ';  
                ' . OxiAddonsFontSettings($styledata, 102) . ';
                ' . OxiAddonsBoxShadowSanitize($styledata, 38) . ';
                }
             .oxi-addons-container .oxi-testimonials-style-' . $oxiid . '-info .fa{
                font-size: ' . $styledata[156] . 'px;
                color:  ' . $styledata[160] . ';
                display: block;
                margin: 0 -' . ($styledata[132] + $styledata[136]) / 4 . 'px
            } 
            .oxi-addons-container  .oxi-testimonials-style-' . $oxiid . '-info .fa-quote-left{
                text-align: left;
            }
             .oxi-addons-container .oxi-testimonials-style-' . $oxiid . '-info .fa-quote-right{
                text-align: right;
            }
             .oxi-addons-container .oxi-testimonials-style-' . $oxiid . '-left{
                width: ' . $styledata[44] . 'px; 
                float: left;
            }
             .oxi-addons-container .oxi-testimonials-style-' . $oxiid . '-right{    
                width: calc(100% - ' . $styledata[44] . 'px);
                padding: 0 ' . $styledata[88] . 'px;    
                float: left;
            }
            .oxi-addons-container  .oxi-addonsdata-right  .oxi-testimonials-style-' . $oxiid . '-left, 
            .oxi-addons-container  .oxi-addonsdata-right .oxi-testimonials-style-' . $oxiid . '-right{
                float: right;
                text-align: right;
            }
             .oxi-addons-container .oxi-testimonials-style-' . $oxiid . '-image{
                margin-top: ' . $styledata[92] . 'px;
                max-width: ' . $styledata[44] . 'px;          
                width: 100%;
                position: relative;
                float: left;                
                border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 72) . ';
                border-width: ' . OxiAddonsPaddingMarginSanitize($styledata, 52) . ';
                border-style:' . $styledata[68] . '; 
                border-color:' . $styledata[69] . '; 
            }
             .oxi-addons-container .oxi-testimonials-style-' . $oxiid . '-image:after{
                padding-bottom:' . $styledata[48] . 'px;
                content: "";
                display: block;
            }
            .oxi-addons-container  .oxi-testimonials-style-' . $oxiid . '-image img{              
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%; 
                display: block;                
                border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 72) . ';
            }
             .oxi-addons-container .oxi-testimonials-style-' . $oxiid . '-name{
                width: 100%;
                float: left; 
                text-align: left;
                color: ' . $styledata[166] . ';
                font-size: ' . $styledata[162] . 'px;
                ' . OxiAddonsFontSettings($styledata, 168) . ';        
                padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 174) . ';
            }
             .oxi-addons-container .oxi-addonsdata-right .oxi-testimonials-style-' . $oxiid . '-name{
                text-align: right;
            }
             .oxi-addons-container .oxi-testimonials-style-' . $oxiid . '-working{
                width: 100%;
                float: left; 
                text-align: left;       
                padding:' . OxiAddonsPaddingMarginSanitize($styledata, 204) . ';              
            } 
            .oxi-addons-container .oxi-testimonials-style-' . $oxiid . '-working a{
                color: ' . $styledata[194] . ';
                font-size: ' . $styledata[190] . 'px;
                ' . OxiAddonsFontSettings($styledata, 198) . '; 
            } 
            .oxi-addons-container  .oxi-testimonials-style-' . $oxiid . '-working a:hover,
             .oxi-addons-container .oxi-testimonials-style-' . $oxiid . '-working a:active,
             .oxi-addons-container .oxi-testimonials-style-' . $oxiid . '-working a:focus{               
                color: ' . $styledata[196] . ';
                text-decoration:none;
            }
            .oxi-addons-container  .oxi-addonsdata-right .oxi-testimonials-style-' . $oxiid . '-working{
                text-align: right;
            }
            @media only screen and (min-width : 669px) and (max-width : 993px){
                .oxi-addons-container  .oxi-testimonials-' . $oxiid . '-padding{
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 16) . '; 
                }
                .oxi-addons-container  .oxi-testimonials-item-' . $oxiid . '{
                    max-width: ' . $styledata[8] . 'px;                    
                }           
                .oxi-addons-container  .oxi-testimonials-style-' . $oxiid . '-info{
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 125) . ';                   
                    font-size: ' . $styledata[97] . 'px;   
                    border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 109) . ';
                    }
                .oxi-addons-container  .oxi-testimonials-style-' . $oxiid . '-info .fa{
                    font-size: ' . $styledata[157] . 'px;                   
                    margin: 0 -' . ($styledata[133] + $styledata[137]) / 4 . 'px
                } 
                .oxi-addons-container  .oxi-testimonials-style-' . $oxiid . '-left{
                    width: ' . $styledata[45] . 'px;                    
                }
                .oxi-addons-container  .oxi-testimonials-style-' . $oxiid . '-right{    
                    width: calc(100% - ' . $styledata[45] . 'px);
                    padding: 0 ' . $styledata[89] . 'px;  
                }
                .oxi-addons-container  .oxi-testimonials-style-' . $oxiid . '-image{
                    margin-top: ' . $styledata[93] . 'px;
                    max-width: ' . $styledata[45] . 'px;  
                    border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 73) . ';
                    border-width: ' . OxiAddonsPaddingMarginSanitize($styledata, 53) . ';                   
                }
                .oxi-addons-container  .oxi-testimonials-style-' . $oxiid . '-image:after{
                    padding-bottom:' . $styledata[49] . 'px;
                }
                .oxi-addons-container  .oxi-testimonials-style-' . $oxiid . '-image img{ 
                    border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 73) . ';
                }
                .oxi-addons-container  .oxi-testimonials-style-' . $oxiid . '-name{                 
                    font-size: ' . $styledata[163] . 'px;                   
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 175) . ';
                }
                .oxi-addons-container  .oxi-testimonials-style-' . $oxiid . '-working{  
                    font-size: ' . $styledata[191] . 'px;                   
                    padding:' . OxiAddonsPaddingMarginSanitize($styledata, 205) . ';              
                }  
            }
            @media only screen and (max-width : 668px){
                .oxi-addons-container  .oxi-testimonials-' . $oxiid . '-padding{
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 17) . '; 
                }
                .oxi-addons-container  .oxi-testimonials-item-' . $oxiid . '{
                    max-width: ' . $styledata[9] . 'px;                    
                }           
                .oxi-addons-container  .oxi-testimonials-style-' . $oxiid . '-info{
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 126) . ';                   
                    font-size: ' . $styledata[98] . 'px;   
                    border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 110) . ';
                    }
                .oxi-addons-container  .oxi-testimonials-style-' . $oxiid . '-info .fa{
                    font-size: ' . $styledata[158] . 'px;                   
                    margin: 0 -' . ($styledata[134] + $styledata[138]) / 4 . 'px
                } 
                .oxi-addons-container  .oxi-testimonials-style-' . $oxiid . '-left{
                    width: ' . $styledata[46] . 'px;                    
                }
                .oxi-addons-container  .oxi-testimonials-style-' . $oxiid . '-right{    
                    width: calc(100% - ' . $styledata[46] . 'px);
                    padding: 0 ' . $styledata[90] . 'px;  
                }
                .oxi-addons-container  .oxi-testimonials-style-' . $oxiid . '-image{
                    margin-top: ' . $styledata[94] . 'px;
                    max-width: ' . $styledata[46] . 'px;  
                    border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 74) . ';
                    border-width: ' . OxiAddonsPaddingMarginSanitize($styledata, 54) . ';                   
                }
                .oxi-addons-container  .oxi-testimonials-style-' . $oxiid . '-image:after{
                    padding-bottom:' . $styledata[50] . 'px;
                }
                .oxi-addons-container  .oxi-testimonials-style-' . $oxiid . '-image img{ 
                    border-radius: ' . OxiAddonsPaddingMarginSanitize($styledata, 74) . ';
                }
                .oxi-addons-container  .oxi-testimonials-style-' . $oxiid . '-name{                 
                    font-size: ' . $styledata[164] . 'px;                   
                    padding: ' . OxiAddonsPaddingMarginSanitize($styledata, 176) . ';
                }
                .oxi-addons-container  .oxi-testimonials-style-' . $oxiid . '-working{  
                    font-size: ' . $styledata[192] . 'px;                   
                    padding:' . OxiAddonsPaddingMarginSanitize($styledata, 206) . ';              
                }  
            }
';
    OxiAddonsInlineCSSData($css);
}
