<?php 
/*
  Plugin Name: Shortcode Addons
  Version: 1.5
 */

return '1.5';