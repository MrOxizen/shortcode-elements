<?php
/*
  Plugin Name: Shortcode Addons
  Version: 1.7.2
 */

return array(1.6, 'Content Elements', true);
